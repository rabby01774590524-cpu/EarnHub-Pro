/**
 * EarnHub Pro - Premium Dark Fintech Earning Platform Core
 */

import { useState, useEffect } from 'react';
import { Home, ClipboardList, Wallet, Users, User, Heart, Coins, LayoutGrid } from 'lucide-react';
import Header from './components/Header';
import AuthView from './components/AuthView';
import DashboardView from './components/DashboardView';
import TasksView from './components/TasksView';
import AccountsView from './components/AccountsView';
import WithdrawView from './components/WithdrawView';
import ReferralView from './components/ReferralView';
import ProfileView from './components/ProfileView';
import WelcomeModal from './components/WelcomeModal';
import SuperAdminExecutiveControlSuite from './components/SuperAdminExecutiveControlSuite';
import { AppUser } from './types';
import { authService } from './services/db';

type TabType = 'home' | 'tasks' | 'accounts' | 'withdraw' | 'refer' | 'profile';

export default function App() {
  const [user, setUser] = useState<AppUser | null>(null);
  const [activeTab, setActiveTab] = useState<TabType>('home');
  const [authReady, setAuthReady] = useState(false);

  useEffect(() => {
    // Listen to Firebase & Local fallback authentications
    const unsubscribe = authService.onStateChanged((appUser) => {
      setUser(appUser);
      setAuthReady(true);
    });
    return () => unsubscribe();
  }, []);

  const handleRefreshUser = () => {
    // Force refresh user from cache/database
    const updatedUser = authService.getCurrentUser();
    if (updatedUser) {
      setUser({ ...updatedUser });
    }
  };

  const handleQuickLogin = (email: string) => {
    authService.signIn(email).then((loggedInUser) => {
      setUser(loggedInUser);
    }).catch(err => console.error(err));
  };

  const handleSignOut = () => {
    authService.signOut();
    setUser(null);
  };

  // Nav configuration entries with Bengali labels and Lucide icons
  const navigationTabsAndIcons = [
    { key: 'home', label: 'হোম', icon: <Home size={20} /> },
    { key: 'tasks', label: 'টাস্ক', icon: <ClipboardList size={20} /> },
    { key: 'accounts', label: 'একাউন্টস সেকশন', icon: <LayoutGrid size={20} /> },
    { key: 'withdraw', label: 'উইথড্র', icon: <Wallet size={20} /> },
    { key: 'refer', label: 'রেফার', icon: <Users size={20} /> },
    { key: 'profile', label: 'প্রোফাইল', icon: <User size={20} /> }
  ];

  if (!authReady) {
    return (
      <div className="min-h-screen bg-[#0d0f12] flex items-center justify-center font-mono text-xs text-gray-500">
        EarnHub Pro loading secure gateways...
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0d0f12] text-gray-100 flex flex-col relative">
      
      {/* 1. Welcoming modal triggers once per browser session */}
      {user && <WelcomeModal />}

      {/* 2. Top Header Navigation branding block */}
      <Header user={user} onQuickLogin={handleQuickLogin} />

      {/* 3. Core content container switch */}
      <main className="flex-1 w-full max-w-6xl mx-auto px-4 py-6 md:py-8 pb-24">
        {user ? (
          <div>
            {activeTab === 'home' && (
              user.email === 'bristysadia15@gmail.com' || user.email === 'bristysadia10@gmail.com' ? (
                <SuperAdminExecutiveControlSuite user={user} />
              ) : (
                <DashboardView user={user} onRefreshUser={handleRefreshUser} />
              )
            )}
            {activeTab === 'tasks' && (
              <TasksView user={user} onRefreshUser={handleRefreshUser} />
            )}
            {activeTab === 'accounts' && (
              <AccountsView user={user} onRefreshUser={handleRefreshUser} />
            )}
            {activeTab === 'withdraw' && (
              <WithdrawView user={user} onRefreshUser={handleRefreshUser} />
            )}
            {activeTab === 'refer' && (
              <ReferralView user={user} />
            )}
            {activeTab === 'profile' && (
              <ProfileView user={user} onSignOut={handleSignOut} />
            )}
          </div>
        ) : (
          <AuthView onSuccess={(loggedInUser) => setUser(loggedInUser)} />
        )}
      </main>

      {/* 4. FOOTER & FIXED GLASSMORPHISM NAVIGATION BAR (SPECIFICATION 1) */}
      {user && (
        <nav 
          id="premium-glassmorphic-bottom-nav"
          className="fixed bottom-0 left-0 right-0 z-40 bg-[#0d0f12]/85 backdrop-blur-md border-t border-neon-green/30 h-20 shadow-[0_-5px_30px_rgba(0,186,129,0.08)]"
        >
          <div className="max-w-md mx-auto h-full flex items-center justify-around px-4">
            {navigationTabsAndIcons.map((tab) => (
              <button
                key={tab.key}
                id={`nav-tab-${tab.key}`}
                onClick={() => setActiveTab(tab.key as TabType)}
                className={`flex flex-col items-center justify-center gap-1.5 flex-1 py-2 text-center relative transition-all cursor-pointer ${
                  activeTab === tab.key 
                    ? 'text-neon-green neon-text-glow font-bold' 
                    : 'text-gray-400 hover:text-gray-200'
                }`}
              >
                {/* Active Underline element */}
                {activeTab === tab.key && (
                  <span className="absolute top-[-10px] w-8 h-[2px] bg-neon-green rounded-full shadow-[0_0_12px_#00E676]" />
                )}
                
                <div className={`transition-transform duration-200 ${activeTab === tab.key ? 'scale-110 text-neon-green' : ''}`}>
                  {tab.icon}
                </div>
                <span className="text-[10px] tracking-wide font-sans block">{tab.label}</span>
              </button>
            ))}
          </div>
        </nav>
      )}
    </div>
  );
}
