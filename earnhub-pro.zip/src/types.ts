/**
 * EarnHub Pro - Typings & Definitions
 */

export interface AppUser {
  uid: string;
  email: string;
  fullName?: string;
  phoneNumber?: string;
  balance: number;
  totalEarned: number;
  referralCode: string;
  referredBy?: string;
  createdAt: string;
  isAdmin: boolean;
  isBlocked?: boolean;
}

export interface EarnTask {
  id: string;
  title: string;
  reward: number;
  type: 'automatic' | 'manual' | 'web_visit';
  duration?: number; // duration for automatic tasks in seconds
  description: string;
  claimedBy: string[]; // List of user UIDs who claimed it today (or permanently)
  targetUrl?: string; // target link for the sponsor/review action
  downloadLink?: string; // App download link for manual review tasks
  soldOut?: boolean;
}

export interface GatewayConfig {
  id: 'bKash' | 'Nagad' | 'Rocket' | 'Binance';
  name: string;
  min: number;
  max: number;
  soldOut: boolean;
}

export interface TaskSubmission {
  id: string;
  userId: string;
  userEmail: string;
  taskName: string;
  taskId: string;
  screenshotUrl: string; // Base64 or mock/real URL
  status: 'Pending' | 'Approved' | 'Rejected';
  reward: number;
  createdAt: string;
}

export interface WithdrawalRequest {
  id: string;
  userId: string;
  userEmail: string;
  amount: number;
  paymentMethod: 'bKash' | 'Nagad' | 'Rocket' | 'Binance';
  accountNumber: string;
  status: 'Pending' | 'Approved' | 'Rejected';
  createdAt: string;
}

export interface ReferralRecord {
  id: string;
  referrerUid: string;
  refereeUid: string;
  refereeEmail: string;
  reward: number;
  createdAt: string;
}

export interface AccountConfig {
  id: string; // e.g. 'gmail', 'telegram', 'instagram', 'facebook'
  title: string;
  reward: number;
  soldOut: boolean;
  description: string;
}

export interface SubmittedAccount {
  id: string;
  userId: string;
  userEmail: string;
  accountType: string;
  accountId: string;
  accountPassword?: string;
  reward: number;
  status: 'Pending' | 'Approved' | 'Rejected';
  submittedAt: string;
}

export interface SystemConfig {
  withdrawalCommissionPercent: number; // default is 10 for 10%
}

