import { Coins, Zap, ShieldCheck } from 'lucide-react';
import { AppUser } from '../types';

interface HeaderProps {
  user: AppUser | null;
  onQuickLogin?: (email: string) => void;
}

export default function Header({ user, onQuickLogin }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 bg-[#0d0f12]/80 backdrop-blur-md border-b border-gray-905 p-4 md:px-6">
      <div className="max-w-6xl mx-auto flex items-center justify-between">
        
        {/* Branding Title */}
        <div className="flex items-center gap-2.5">
          <div className="relative flex items-center justify-center p-2 rounded-xl bg-gradient-to-br from-emerald-500 to-neon-green text-black font-extrabold font-display shadow-[0_0_15px_rgba(0,230,118,0.3)] select-none">
            <Coins size={20} className="animate-spin" style={{ animationDuration: '6s' }} />
          </div>
          <div>
            <h1 className="font-display font-black text-white text-lg tracking-tight select-none">
              EarnHub <span className="text-neon-green">Pro</span>
            </h1>
            <p className="text-[9px] text-gray-500 font-mono tracking-widest uppercase">Verified Payouts</p>
          </div>
        </div>

        {/* Global actions / Balance pill */}
        <div className="flex items-center gap-3">
          
          {/* Simulated Dev Fast logins */}
          {!user && onQuickLogin && (
            <div className="hidden sm:flex items-center gap-2">
              <button
                id="dev-login-user"
                onClick={() => onQuickLogin('earner@test.com')}
                className="text-[10px] font-bold font-mono px-2 py-1.5 rounded bg-gray-900 border border-gray-800 hover:border-gray-700 text-gray-400 cursor-pointer"
              >
                + Earn Account
              </button>
              <button
                id="dev-login-admin"
                onClick={() => onQuickLogin('bristysadia10@gmail.com')}
                className="text-[10px] font-bold font-mono px-2 py-1.5 rounded bg-red-950/20 border border-red-900/30 text-red-400 hover:bg-red-950/50 cursor-pointer"
              >
                + Admin Portal
              </button>
            </div>
          )}

          {user && (
            <div className="flex items-center gap-2.5">
              {/* Admin marker indicator badge */}
              {user.isAdmin && (
                <div className="hidden sm:flex items-center gap-1.5 bg-red-500/10 border border-red-500/20 text-red-400 text-[10px] font-bold px-2.5 py-1.5 rounded-full uppercase font-mono">
                  <ShieldCheck size={12} /> Executive
                </div>
              )}

              {/* Cash Wallet statistics overlay pill */}
              <div className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-gray-950/80 border border-gray-850">
                <Coins size={14} className="text-neon-green" />
                <span className="text-xs text-gray-400">ব্যালেন্স:</span>
                <span className="text-sm font-mono font-bold text-white">৳{user.balance.toFixed(2)}</span>
              </div>
            </div>
          )}

        </div>

      </div>
    </header>
  );
}
