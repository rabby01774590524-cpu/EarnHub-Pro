import { useState, useEffect } from 'react';
import { Gift, Wallet, ArrowUpRight, Award, Send, Users, Facebook, Instagram, Music, Bell } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppUser } from '../types';
import { databaseService } from '../services/db';

interface DashboardViewProps {
  user: AppUser;
  onRefreshUser: () => void;
}

export default function DashboardView({ user, onRefreshUser }: DashboardViewProps) {
  const [checkingIn, setCheckingIn] = useState(false);
  const [checkInReward, setCheckInReward] = useState<number | null>(null);
  const [hasCheckedInToday, setHasCheckedInToday] = useState(false);

  useEffect(() => {
    const lastCheck = localStorage.getItem(`earnhub_last_check_${user.uid}`);
    const today = new Date().toDateString();
    if (lastCheck === today) {
      setHasCheckedInToday(true);
    }
  }, [user.uid]);

  const handleDailyCheckIn = async () => {
    if (hasCheckedInToday || checkingIn) return;
    setCheckingIn(true);
    try {
      const reward = await databaseService.claimDailyCheckIn(user.uid);
      setCheckInReward(reward);
      setHasCheckedInToday(true);
      localStorage.setItem(`earnhub_last_check_${user.uid}`, new Date().toDateString());
      onRefreshUser();
    } catch (err) {
      console.error(err);
    } finally {
      setCheckingIn(false);
    }
  };

  const supportLinks = [
    {
      name: 'টেলিগ্রাম সাপোর্ট গ্রুপ',
      url: 'https://t.me/EarnHubPro1',
      icon: <Send size={20} className="fill-white" />,
      color: 'from-sky-500 to-blue-600',
      description: 'লাইভ এডমিন সাপোর্ট ও পেমেন্ট প্রুফ',
    },
    {
      name: 'ফেসবুক পেজ',
      url: 'https://www.facebook.com/share/1Km9sgM2eB/',
      icon: <Facebook size={20} className="fill-white" />,
      color: 'from-blue-600 to-indigo-700',
      description: 'অফিশিয়াল ক্যাম্পেইন ও আপডেট',
    },
    {
      name: 'ইনস্টাগ্রাম সাপোর্ট',
      url: 'https://www.instagram.com/earnhubpro1?igsh=MTUzYTJhZDA3d2NqdQ==',
      icon: <Instagram size={20} />,
      color: 'from-pink-600 to-rose-500',
      description: 'ডিজিটাল ইভেন্ট ও ফোটো গ্যালারি',
    },
    {
      name: 'টিকটক কারেন্ট ফিড',
      url: 'https://www.tiktok.com/@earnhubpro?_r=1&_t=ZS-96qyXgmAMnl',
      icon: <Music size={20} />,
      color: 'from-black to-slate-800',
      border: 'border-slate-700',
      description: 'পেমেন্ট প্রুফ ও মেম্বার ভিডিও রিভিউ',
    }
  ];

  return (
    <div className="space-y-6">
      {/* 1. Header Hero Status */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-b from-[#13171e] to-[#0a0c10] border border-gray-800 p-6 md:p-8">
        {/* Glow backdrop circles */}
        <div className="absolute top-0 right-0 w-48 h-48 bg-neon-green/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute -bottom-10 -left-10 w-40 h-40 bg-emerald-500/5 rounded-full blur-3xl pointer-events-none" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-6 relative z-10">
          <div>
            <div className="flex items-center gap-2 text-xs bg-neon-green/10 text-neon-green px-2.5 py-1 rounded-full border border-neon-green/20 w-fit mb-3">
              <span className="w-1.5 h-1.5 rounded-full bg-neon-green animate-ping" />
              প্রিমিয়াম মেম্বার একাউন্ট
            </div>
            <h2 className="text-2xl md:text-3xl font-display font-bold text-white tracking-tight">
              সুস্বাগতম, <span className="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-neon-green">{user.email.split('@')[0]}</span>
            </h2>
            <p className="text-gray-400 text-sm mt-1">
              বাংলাদেশি বিশ্বস্ত নম্বর ১ আর্নিং সলিউশনস প্লাটফর্মে স্বাগতম।
            </p>
          </div>

          {/* Quick Check-in Module */}
          <div className="shrink-0">
            {hasCheckedInToday ? (
              <div className="flex flex-col items-center bg-gray-900/80 border border-gray-800 px-5 py-4 rounded-xl text-center">
                <span className="text-gray-500 text-xs uppercase tracking-wider font-mono">ডেইলি চেকিং</span>
                <span className="text-emerald-400 font-bold font-mono text-sm mt-1.5 flex items-center gap-1.5">
                  <Gift size={16} /> দাবি করা হয়েছে
                </span>
              </div>
            ) : (
              <motion.button
                id="daily-checkin-btn"
                whileHover={{ scale: 1.03 }}
                whileTap={{ scale: 0.98 }}
                onClick={handleDailyCheckIn}
                disabled={checkingIn}
                className="flex items-center gap-2.5 bg-gradient-to-r from-emerald-500 via-neon-green to-teal-400 text-black font-bold font-display px-6 py-4 rounded-xl hover:neon-btn-glow active:brightness-95 transition-all shadow-[0_4px_25px_rgba(0,230,118,0.25)]"
              >
                <Gift size={18} />
                {checkingIn ? 'চেকিং হচ্ছে...' : 'আজকের বোনাস দাবি করুন'}
              </motion.button>
            )}
          </div>
        </div>

        {/* Claim Animated Dialog */}
        <AnimatePresence>
          {checkInReward !== null && (
            <motion.div
              initial={{ scale: 0.8, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.8, opacity: 0 }}
              className="mt-4 p-4 rounded-xl bg-neon-green/10 border border-neon-green/30 text-neon-green text-center"
            >
              🎉 অভিনন্দন! আপনি আজকের ডেইলি চেকিং বোনাস হিসেবে{' '}
              <span className="font-bold underline text-white">৳{checkInReward.toFixed(2)}</span> টাকা এবং জিপিএস পয়েন্ট পেয়েছেন!
              <button 
                className="ml-3 font-mono font-bold text-xs bg-neon-green text-black px-2 py-0.5 rounded"
                onClick={() => setCheckInReward(null)}
              >
                ঠিক আছে
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* 2. Visual Account Grid Indicators */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Balance Stat */}
        <div className="bg-[#12161a] border border-gray-800/80 rounded-xl p-5 hover:border-gray-700 transition">
          <div className="flex items-center justify-between">
            <span className="text-gray-400 text-xs tracking-wider uppercase font-mono">বর্তমান ব্যালেন্স</span>
            <div className="p-2 rounded-lg bg-neon-green/5 text-neon-green">
              <Wallet size={18} />
            </div>
          </div>
          <p className="text-3xl font-mono font-bold text-white tracking-tight mt-3">
            ৳{user.balance.toFixed(2)}
          </p>
          <div className="flex items-center text-xs text-neon-green/70 gap-1 mt-2">
            <span>উত্তোলনের জন্য প্রস্তুত</span>
            <ArrowUpRight size={14} />
          </div>
        </div>

        {/* Total Earned Stat */}
        <div className="bg-[#12161a] border border-gray-800/80 rounded-xl p-5 hover:border-gray-700 transition">
          <div className="flex items-center justify-between">
            <span className="text-gray-400 text-xs tracking-wider uppercase font-mono">মোট অর্জিত আয়</span>
            <div className="p-2 rounded-lg bg-emerald-500/5 text-emerald-400">
              <Award size={18} />
            </div>
          </div>
          <p className="text-3xl font-mono font-bold text-emerald-400 tracking-tight mt-3">
            ৳{user.totalEarned.toFixed(2)}
          </p>
          <div className="text-xs text-gray-500 mt-2">
            সর্বমোট অর্জিত টাকার হিসাব
          </div>
        </div>

        {/* Invite Code / Referral Code */}
        <div className="bg-[#12161a] border border-gray-800/80 rounded-xl p-5 hover:border-gray-700 transition">
          <div className="flex items-center justify-between">
            <span className="text-gray-400 text-xs tracking-wider uppercase font-mono">আপনার রেফার কোড</span>
            <div className="p-2 rounded-lg bg-teal-500/5 text-teal-400">
              <Users size={18} />
            </div>
          </div>
          <p className="text-3xl font-mono font-bold text-teal-400 tracking-tight mt-3 uppercase">
            {user.referralCode}
          </p>
          <div className="text-xs text-gray-500 mt-2">
            ১০% আজীবন রেফার কমিশন (Lifetime Active Share)
          </div>
        </div>
      </div>

      {/* 3. Official Brands Support Desk Links */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-1.5 h-6 bg-neon-green rounded-full" />
          <h3 className="font-display text-lg font-bold text-white">অফিশিয়াল সোশ্যাল চ্যানেল ও সাপোর্ট ডেস্ক</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {supportLinks.map((item, index) => (
            <motion.a
              key={index}
              id={`quick-link-${index}`}
              href={item.url}
              target="_blank"
              rel="noreferrer referrer"
              whileHover={{ scale: 1.01, border: '1px solid rgba(0, 230, 118, 0.4)' }}
              className={`flex items-center gap-4 bg-[#12161a] border border-gray-800 p-4 rounded-xl transition-all shadow-sm`}
            >
              <div className={`p-3 rounded-xl bg-gradient-to-br ${item.color} text-white shrink-0`}>
                {item.icon}
              </div>
              <div className="flex-1">
                <span className="font-bold text-sm text-white flex items-center justify-between">
                  {item.name}
                  <span className="text-neon-green font-normal text-xs font-mono">ক্লিক করুন →</span>
                </span>
                <p className="text-xs text-gray-400 mt-1">
                  {item.description}
                </p>
              </div>
            </motion.a>
          ))}
        </div>
      </div>

      {/* 4. Tips & Notices */}
      <div className="border border-amber-500/20 bg-amber-500/5 p-4 rounded-xl flex items-start gap-3">
        <Bell className="text-amber-400 mt-0.5 shrink-0" size={18} />
        <div>
          <h4 className="font-bold text-amber-300 text-sm">সতর্ক বার্তা ও পেমেন্ট রুলস:</h4>
          <p className="text-xs text-gray-300 mt-1 leading-relaxed">
            কোনো প্রকার ভিপিএন ব্যবহার করে স্পন্সর অ্যাড টাস্ক সম্পন্ন করবেন না। একাধিক একাউন্ট তৈরি করলে আপনার সম্পূর্ণ আর্নিং বাতিল করা হতে পারে। ২৪ ঘণ্টার মধ্যে আপনার বিকাশ, নগদ বা রকেটে টাকা পাঠানো হবে।
          </p>
        </div>
      </div>
    </div>
  );
}
