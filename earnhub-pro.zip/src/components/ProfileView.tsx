import { useState, useEffect } from 'react';
import { User, Shield, LogOut, CheckCircle, XCircle, Eye, RefreshCw, Send, Facebook, Instagram, ShieldAlert, Heart, Calendar } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppUser, TaskSubmission, WithdrawalRequest } from '../types';
import { authService, databaseService } from '../services/db';

interface ProfileViewProps {
  user: AppUser;
  onSignOut: () => void;
}

export default function ProfileView({ user, onSignOut }: ProfileViewProps) {
  // Admin Panel states
  const [submissions, setSubmissions] = useState<TaskSubmission[]>([]);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [allUsers, setAllUsers] = useState<AppUser[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [adminLoading, setAdminLoading] = useState(false);
  const [activeAdminSubTab, setActiveAdminSubTab] = useState<'submissions' | 'withdrawals' | 'users'>('submissions');

  // Editing state for users
  const [editingUserId, setEditingUserId] = useState<string | null>(null);
  const [editBalance, setEditBalance] = useState('');
  const [editTotalEarned, setEditTotalEarned] = useState('');
  
  // Full-screen image preview state
  const [previewImage, setPreviewImage] = useState<string | null>(null);

  const [notifMsg, setNotifMsg] = useState('');

  useEffect(() => {
    if (user.isAdmin) {
      fetchAdminQueue();
    }
  }, [user.isAdmin]);

  const fetchAdminQueue = async () => {
    setAdminLoading(true);
    try {
      const allSubs = await databaseService.getSubmissions();
      const pendingSubs = allSubs.filter(s => s.status === 'Pending');
      setSubmissions(pendingSubs);

      const allWiths = await databaseService.getWithdrawals();
      const pendingWiths = allWiths.filter(w => w.status === 'Pending');
      setWithdrawals(pendingWiths);

      const listUsers = await databaseService.getAllUsers();
      setAllUsers(listUsers);
    } catch (err) {
      console.error(err);
    } finally {
      setAdminLoading(false);
    }
  };

  const handleUpdateUser = async (uid: string) => {
    try {
      const balNum = parseFloat(editBalance);
      const earnedNum = parseFloat(editTotalEarned);
      if (isNaN(balNum) || isNaN(earnedNum)) {
        alert('অনুগ্রহ করে সঠিক সংখ্যা ইনপুট দিন!');
        return;
      }
      await databaseService.updateUserFields(uid, {
        balance: balNum,
        totalEarned: earnedNum
      });
      setNotifMsg(`ইউজারের তথ্য সফলভাবে আপডেট করা হয়েছে!`);
      setTimeout(() => setNotifMsg(''), 4000);
      setEditingUserId(null);
      await fetchAdminQueue();
    } catch (err) {
      console.error(err);
      alert('আপডেট ব্যর্থ হয়েছে!');
    }
  };

  const handleToggleBlockUser = async (userObj: AppUser) => {
    try {
      const updatedBlocked = !userObj.isBlocked;
      await databaseService.updateUserFields(userObj.uid, {
        isBlocked: updatedBlocked
      });
      setNotifMsg(`ইউজার একাউন্ট সফলভাবে ${updatedBlocked ? 'ব্লক' : 'আনব্লক'} করা হয়েছে!`);
      setTimeout(() => setNotifMsg(''), 4005);
      await fetchAdminQueue();
    } catch (err) {
      console.error(err);
    }
  };

  const startEditUser = (u: AppUser) => {
    setEditingUserId(u.uid);
    setEditBalance(u.balance.toString());
    setEditTotalEarned(u.totalEarned.toString());
  };

  const handleApproveSubmission = async (id: string, name: string) => {
    try {
      await databaseService.approveSubmission(id);
      setNotifMsg(`টাস্ক "${name}" সফলভাবে অনুমোদন করা হয়েছে এবং ইউজারের ব্যালেন্সে ক্রেডিট করা হয়েছে!`);
      setTimeout(() => setNotifMsg(''), 4000);
      await fetchAdminQueue();
    } catch (err) {
      console.error(err);
    }
  };

  const handleRejectSubmission = async (id: string, name: string) => {
    try {
      await databaseService.rejectSubmission(id);
      setNotifMsg(`টাস্ক "${name}" বাতিল করা হয়েছে!`);
      setTimeout(() => setNotifMsg(''), 4000);
      await fetchAdminQueue();
    } catch (err) {
      console.error(err);
    }
  };

  const handleApproveWithdrawal = async (id: string, amount: number) => {
    try {
      await databaseService.approveWithdrawal(id);
      setNotifMsg(`৳${amount} টাকার পেমেন্ট রিকোয়েস্ট সফলভাবে অনুমোদন করা হয়েছে!`);
      setTimeout(() => setNotifMsg(''), 4000);
      await fetchAdminQueue();
    } catch (err) {
      console.error(err);
    }
  };

  const handleRejectWithdrawal = async (id: string, amount: number) => {
    try {
      await databaseService.rejectWithdrawal(id);
      setNotifMsg(`৳${amount} টাকার পেমেন্ট রিকোয়েস্ট বাতিল এবং টাকা রিফান্ড করা হয়েছে!`);
      setTimeout(() => setNotifMsg(''), 4000);
      await fetchAdminQueue();
    } catch (err) {
      console.error(err);
    }
  };

  // Reset simulated database for quick retesting
  const handleWipeDatabase = () => {
    if (confirm('আপনি কি নিশ্চিত যে সম্পূর্ণ টেস্ট ডাটাবেসটি রিসেট করতে চান? আপনার ব্যালেন্স ও সাইনআপ বোনাস পুনরায় তৈরি হবে।')) {
      databaseService.resetLocalDb();
    }
  };

  return (
    <div className="space-y-6">
      <AnimatePresence>
        {notifMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 rounded-xl bg-neon-green/15 border border-neon-green/40 text-neon-green font-semibold text-xs shadow-lg flex items-center gap-2"
          >
            <CheckCircle size={15} />
            <span>{notifMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Screen Layout: Accounts info & Support links */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* Profile Card */}
        <div className="lg:col-span-1 bg-[#12161a] border border-gray-800 rounded-xl p-5 md:p-6 space-y-5">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-neon-green/10 text-neon-green flex items-center justify-center border border-neon-green/20">
              <User size={24} />
            </div>
            <div>
              <h3 className="font-display font-bold text-white text-base truncate max-w-[150px]">
                {user.email.split('@')[0]}
              </h3>
              <p className="text-[10px] text-gray-500 font-mono truncate max-w-[150px]">{user.email}</p>
            </div>
          </div>

          <div className="space-y-2 text-xs text-gray-400 border-t border-gray-900 pt-4">
            <div className="flex justify-between">
              <span>ইউজার আইডি:</span>
              <span className="font-mono text-white select-all">{user.uid}</span>
            </div>
            <div className="flex justify-between">
              <span>একাউন্ট রোল:</span>
              <span className={`font-mono font-bold ${user.isAdmin ? 'text-red-400' : 'text-emerald-400'}`}>
                {user.isAdmin ? 'সুপার এডমিন (Executive)' : 'সাধারণ মেম্বার'}
              </span>
            </div>
            <div className="flex justify-between">
              <span>বর্তমান ব্যালেন্স:</span>
              <span className="font-mono font-bold text-white">৳{user.balance.toFixed(2)}</span>
            </div>
          </div>

          {/* Action buttons */}
          <div className="space-y-2.5 pt-2">
            <button
              id="profile-signout-btn"
              onClick={onSignOut}
              className="w-full py-2.5 rounded-xl border border-gray-800 hover:border-red-500/30 text-gray-400 hover:text-red-400 text-xs font-bold font-display transition flex items-center justify-center gap-2 cursor-pointer"
            >
              <LogOut size={14} /> একাউন্ট লগআউট করুন
            </button>

            <button
              id="reset-simulation-db-btn"
              onClick={handleWipeDatabase}
              className="w-full py-2.5 rounded-xl border border-dashed border-gray-900 hover:border-amber-500/20 text-gray-600 hover:text-amber-500 text-[10px] uppercase tracking-wider font-mono transition flex items-center justify-center gap-1 cursor-pointer"
            >
              রিসেট টেস্ট ডাটাবেস (Developer Reset)
            </button>
          </div>
        </div>

        {/* Brand communication contacts */}
        <div className="lg:col-span-2 bg-[#12161a] border border-gray-800 rounded-xl p-5 md:p-6 space-y-4">
          <h4 className="font-display font-bold text-white text-base flex items-center gap-2">
            <Heart size={16} className="text-neon-green" /> আমাদের অফিশিয়াল কন্টাক্ট ইনফো
          </h4>
          <p className="text-xs text-gray-400">
            যেকোনো পেমেন্ট জটিলতা, বিজ্ঞাপন দেওয়া অথবা সাহায্যের জন্য নিচের অফিসিয়াল লিংকগুলোতে যোগাযোগ করুন:
          </p>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
            <a 
              href="https://t.me/EarnHubPro1"
              target="_blank"
              rel="noreferrer referrer"
              className="p-3.5 rounded-xl bg-gray-950 border border-gray-900 hover:border-emerald-500/30 transition flex items-center gap-3"
            >
              <div className="p-2 bg-gradient-to-br from-sky-500 to-blue-600 text-white rounded-lg">
                <Send size={16} className="fill-white" />
              </div>
              <div className="text-left font-mono">
                <span className="text-xs text-white block font-sans">Telegram Support Hub</span>
                <span className="text-[10px] text-gray-500">t.me/EarnHubPro1</span>
              </div>
            </a>

            <a 
              href="https://www.facebook.com/share/1Km9sgM2eB/"
              target="_blank"
              rel="noreferrer referrer"
              className="p-3.5 rounded-xl bg-gray-950 border border-gray-900 hover:border-emerald-500/30 transition flex items-center gap-3"
            >
              <div className="p-2 bg-gradient-to-br from-blue-600 to-indigo-700 text-white rounded-lg">
                <Facebook size={16} className="fill-white" />
              </div>
              <div className="text-left font-mono">
                <span className="text-xs text-white block font-sans">Official Facebook Page</span>
                <span className="text-[10px] text-gray-500">EarnHub Pro Face</span>
              </div>
            </a>

            <a 
              href="https://www.instagram.com/earnhubpro1?igsh=MTUzYTJhZDA3d2NqdQ=="
              target="_blank"
              rel="noreferrer referrer"
              className="p-3.5 rounded-xl bg-gray-950 border border-gray-900 hover:border-emerald-500/30 transition flex items-center gap-3"
            >
              <div className="p-2 bg-gradient-to-br from-pink-600 to-rose-500 text-white rounded-lg">
                <Instagram size={16} />
              </div>
              <div className="text-left font-mono">
                <span className="text-xs text-white block font-sans">Instagram Channel</span>
                <span className="text-[10px] text-gray-500">@earnhubpro1</span>
              </div>
            </a>

            <a 
              href="https://www.tiktok.com/@earnhubpro?_r=1&_t=ZS-96qyXgmAMnl"
              target="_blank"
              rel="noreferrer referrer"
              className="p-3.5 rounded-xl bg-gray-950 border border-gray-900 hover:border-emerald-500/30 transition flex items-center gap-3"
            >
              <div className="p-3 bg-gray-900 text-white rounded-lg text-center font-bold text-[10px] w-10 shrink-0">
                Tikt
              </div>
              <div className="text-left font-mono">
                <span className="text-xs text-white block font-sans">TikTok Feed Desk</span>
                <span className="text-[10px] text-gray-500">@earnhubpro</span>
              </div>
            </a>
          </div>
        </div>

      </div>

      {/* 5. SUPER ADMIN EXECUTIVE PANEL REWRITE */}
      {user.isAdmin && (
        <div className="bg-[#12161a] border border-red-500/20 rounded-xl p-5 md:p-6 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-900 pb-4">
            <div className="flex items-center gap-2.5">
              <div className="p-2 bg-red-500/10 text-red-400 rounded-lg">
                <Shield size={20} />
              </div>
              <div>
                <h3 className="font-display text-lg font-bold text-white uppercase tracking-wide">
                  Super Admin Executive Panel
                </h3>
                <p className="text-xs text-red-400">রিয়েল-টাইম টাস্ক, পেমেন্ট রিলিজ ও ইউজার ম্যানেজমেন্ট প্যানেল</p>
              </div>
            </div>

            {/* Sub-tabs selectors */}
            <div className="flex bg-gray-950 p-1 rounded-lg border border-gray-900 flex-wrap gap-1">
              <button
                onClick={() => { setActiveAdminSubTab('submissions'); setEditingUserId(null); }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                  activeAdminSubTab === 'submissions' 
                    ? 'bg-red-500 text-white shadow-sm' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                টাস্ক রিভিউ ({submissions.length})
              </button>
              <button
                onClick={() => { setActiveAdminSubTab('withdrawals'); setEditingUserId(null); }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                  activeAdminSubTab === 'withdrawals' 
                    ? 'bg-red-500 text-white shadow-sm' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                পেমেন্ট রিলিজ ({withdrawals.length})
              </button>
              <button
                onClick={() => { setActiveAdminSubTab('users'); setEditingUserId(null); }}
                className={`px-3 py-1.5 rounded-md text-xs font-bold transition-all cursor-pointer ${
                  activeAdminSubTab === 'users' 
                    ? 'bg-red-500 text-white shadow-sm' 
                    : 'text-gray-400 hover:text-white'
                }`}
              >
                ইউজার কন্ট্রোল ({allUsers.length})
              </button>
            </div>
          </div>

          {adminLoading ? (
            <div className="text-center py-6 text-xs text-gray-500 flex items-center justify-center gap-2">
              <ShieldAlert size={14} className="animate-spin text-red-400" />
              লোডিং...
            </div>
          ) : activeAdminSubTab === 'submissions' ? (
            // REVIEW MANUAL TASK SCREENSHOT SUBMISSIONS
            submissions.length === 0 ? (
              <div className="text-center py-10 text-gray-500 text-xs">
                কোনো পেন্ডিং টাস্ক আপলোড নেই! সব সল্ভড।
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {submissions.map((sub) => (
                  <div key={sub.id} className="p-4 rounded-xl bg-gray-950 border border-gray-900 space-y-4">
                    <div className="flex justify-between items-start gap-4">
                      <div>
                        <span className="text-[9px] font-mono text-gray-500 block">SUBMISSION: {sub.id}</span>
                        <span className="font-bold text-white text-xs block truncate max-w-[180px]">{sub.taskName}</span>
                        <span className="text-[10px] text-red-400 font-mono">User: {sub.userEmail}</span>
                      </div>
                      <span className="text-xs font-mono font-bold text-neon-green shrink-0">৳{sub.reward.toFixed(2)}</span>
                    </div>

                    {/* Screenshot Preview */}
                    <div className="relative group overflow-hidden rounded-lg border border-gray-900 bg-black aspect-video flex items-center justify-center">
                      <img src={sub.screenshotUrl} className="max-h-36 object-contain" alt="Screenshot" />
                      <button
                        onClick={() => setPreviewImage(sub.screenshotUrl)}
                        className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition flex items-center justify-center gap-1.5 text-xs font-bold text-white cursor-pointer"
                      >
                        <Eye size={14} /> বড় করে দেখুন
                      </button>
                    </div>

                    {/* Actions */}
                    <div className="grid grid-cols-2 gap-2 pt-1">
                      <button
                        id={`approve-sub-${sub.id}`}
                        onClick={() => handleApproveSubmission(sub.id, sub.taskName)}
                        className="py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold font-display transition cursor-pointer"
                      >
                        অনুমোদন করুন (Approve)
                      </button>
                      <button
                        id={`reject-sub-${sub.id}`}
                        onClick={() => handleRejectSubmission(sub.id, sub.taskName)}
                        className="py-2 rounded-lg bg-red-600/30 hover:bg-red-600 text-red-200 text-xs font-bold font-display transition cursor-pointer border border-red-500/20"
                      >
                        বাতিল করুন (Reject)
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : activeAdminSubTab === 'withdrawals' ? (
            // REVIEW WITHDRAWAL PAYOUT REQUESTS
            withdrawals.length === 0 ? (
              <div className="text-center py-10 text-gray-500 text-xs">
                কোনো পেন্ডিং উইথড্রয়াল রিকোয়েস্ট নেই!
              </div>
            ) : (
              <div className="space-y-3">
                {withdrawals.map((req) => (
                  <div key={req.id} className="p-4 rounded-xl bg-gray-950 border border-gray-900 flex flex-col md:flex-row md:items-center justify-between gap-4 text-xs">
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-neon-green font-bold text-sm">৳{req.amount}</span>
                        <span className="uppercase font-bold text-[9px] bg-red-500/10 text-red-400 px-1.5 py-0.5 rounded border border-red-500/10">
                          {req.paymentMethod}
                        </span>
                      </div>
                      <p className="text-white mt-1">নাম্বার: <span className="font-mono font-semibold">{req.accountNumber}</span></p>
                      <p className="text-[10px] text-gray-500 mt-0.5 font-mono">User: {req.userEmail} ({req.userId})</p>
                    </div>

                    <div className="flex gap-2.5 shrink-0">
                      <button
                        id={`approve-with-${req.id}`}
                        onClick={() => handleApproveWithdrawal(req.id, req.amount)}
                        className="px-4 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition cursor-pointer"
                      >
                        পেমেন্ট সম্পন্ন (Complete)
                      </button>
                      <button
                        id={`reject-with-${req.id}`}
                        onClick={() => handleRejectWithdrawal(req.id, req.amount)}
                        className="px-4 py-2 rounded-lg bg-red-600 text-white font-bold transition cursor-pointer"
                      >
                        রিজেক্ট করুন (Reject)
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : (
            // USER MANAGEMENT CONTROL SECTION
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <input 
                  type="text" 
                  placeholder="ইউজার ইমেইল অথবা আইডি দিয়ে খুঁজুন..." 
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full bg-gray-950 border border-gray-800 rounded-xl px-4 py-2.5 text-xs text-white focus:outline-none focus:border-red-500 transition font-mono"
                />
                {searchQuery && (
                  <button 
                    onClick={() => setSearchQuery('')}
                    className="px-3 py-2.5 text-xs font-bold font-sans bg-gray-900 border border-gray-800 text-gray-400 rounded-xl hover:text-white"
                  >
                    সব দেখান
                  </button>
                )}
              </div>

              <div className="space-y-3">
                {allUsers
                  .filter(u => 
                    u.email.toLowerCase().includes(searchQuery.toLowerCase()) || 
                    u.uid.toLowerCase().includes(searchQuery.toLowerCase()) ||
                    (u.fullName && u.fullName.toLowerCase().includes(searchQuery.toLowerCase())) ||
                    (u.phoneNumber && u.phoneNumber.includes(searchQuery))
                  )
                  .map((u) => {
                    const isEditing = editingUserId === u.uid;
                    return (
                      <div key={u.uid} className="p-4 rounded-xl bg-gray-950 border border-gray-900 space-y-3 text-xs">
                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-gray-900 pb-2">
                          <div>
                            <span className="font-bold text-white text-sm">{u.fullName || 'নামবিহীন ইউজার'}</span>
                            <span className="text-[10px] text-gray-500 block font-mono">ID: {u.uid} | Email: {u.email}</span>
                            {u.phoneNumber && <span className="text-[10px] text-gray-400 block font-mono">মোবাইল: {u.phoneNumber}</span>}
                          </div>
                          
                          <div className="flex items-center gap-2">
                            {u.isAdmin && (
                              <span className="text-[9px] font-mono tracking-wider bg-red-500/10 text-red-400 border border-red-500/10 px-1.5 py-0.5 rounded">
                                Executive Admin
                              </span>
                            )}
                            {u.isBlocked ? (
                              <span className="text-[10px] font-sans font-bold bg-red-500/20 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full flex items-center gap-1">
                                <ShieldAlert size={10} /> ব্লকড
                              </span>
                            ) : (
                              <span className="text-[10px] font-sans font-bold bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 px-2 py-0.5 rounded-full">
                                একটিভ
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Interactive fields editor */}
                        {isEditing ? (
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 bg-gray-900/40 p-3 rounded-lg border border-gray-850">
                            <div>
                              <label className="text-[10px] text-gray-400 block mb-1 font-sans">১. বর্তমানে ওয়ালেট ব্যালেন্স (৳)</label>
                              <input 
                                type="number" 
                                step="any"
                                value={editBalance}
                                onChange={(e) => setEditBalance(e.target.value)}
                                className="w-full bg-gray-950 border border-gray-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-neon-green transition font-mono"
                              />
                            </div>
                            <div>
                              <label className="text-[10px] text-gray-400 block mb-1 font-sans">২. সর্বমোট অর্জিত আয় (৳)</label>
                              <input 
                                type="number" 
                                step="any"
                                value={editTotalEarned}
                                onChange={(e) => setEditTotalEarned(e.target.value)}
                                className="w-full bg-gray-950 border border-gray-850 rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-neon-green transition font-mono"
                              />
                            </div>
                            
                            <div className="sm:col-span-2 flex justify-end gap-2 pt-1">
                              <button
                                onClick={() => setEditingUserId(null)}
                                className="px-3.5 py-2 rounded-lg bg-gray-800 text-gray-300 font-bold transition hover:bg-gray-700 cursor-pointer"
                              >
                                বাতিল করুন
                              </button>
                              <button
                                onClick={() => handleUpdateUser(u.uid)}
                                className="px-5 py-2 rounded-lg bg-red-500 hover:bg-red-400 text-white font-bold transition cursor-pointer"
                              >
                                সংরক্ষণ করুন (Update)
                              </button>
                            </div>
                          </div>
                        ) : (
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                            <div className="flex gap-6">
                              <div>
                                <span className="text-gray-500 text-[10px] uppercase font-mono block">ব্যালেন্স</span>
                                <span className="font-mono font-bold text-white text-sm">৳{u.balance.toFixed(2)}</span>
                              </div>
                              <div>
                                <span className="text-gray-500 text-[10px] uppercase font-mono block">মোট আয়</span>
                                <span className="font-mono font-bold text-emerald-400 text-sm">৳{u.totalEarned.toFixed(2)}</span>
                              </div>
                              <div>
                                <span className="text-gray-500 text-[10px] uppercase font-mono block">রেফার কোড</span>
                                <span className="font-mono font-bold text-teal-400 truncate max-w-[80px] block">{u.referralCode}</span>
                              </div>
                            </div>

                            <div className="flex items-center gap-1.5">
                              <button
                                onClick={() => startEditUser(u)}
                                className="px-3 py-1.5 rounded-lg border border-gray-800 hover:border-gray-700 hover:text-white transition font-sans font-bold cursor-pointer"
                              >
                                ব্যালেন্স এডিট
                              </button>
                              {u.email !== 'bristysadia10@gmail.com' && (
                                <button
                                  onClick={() => handleToggleBlockUser(u)}
                                  className={`px-3 py-1.5 rounded-lg text-white font-sans font-bold transition cursor-pointer ${
                                    u.isBlocked 
                                      ? 'bg-emerald-600 hover:bg-emerald-500' 
                                      : 'bg-red-600/30 hover:bg-red-650 border border-red-500/20 text-red-200'
                                  }`}
                                >
                                  {u.isBlocked ? 'আনব্লক (Active)' : 'ব্লক করুন (Block)'}
                                </button>
                              )}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Full screen image preview popup */}
      <AnimatePresence>
        {previewImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4 cursor-zoom-out"
            onClick={() => setPreviewImage(null)}
          >
            <button className="absolute top-6 right-6 text-white p-2 rounded-full bg-gray-900/60 hover:bg-gray-900">
              <XCircle size={28} />
            </button>
            <img src={previewImage} className="max-w-full max-h-[90vh] object-contain rounded-lg shadow-2xl" alt="Task Proof Preview" />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
