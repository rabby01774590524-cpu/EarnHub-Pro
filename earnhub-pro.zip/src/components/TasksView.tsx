import React, { useState, useEffect, useRef } from 'react';
import { Play, CheckCircle, Clock, UploadCloud, FileText, AlertCircle, Eye, AlertTriangle, Download, ExternalLink, Globe, Lock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppUser, EarnTask, TaskSubmission } from '../types';
import { databaseService } from '../services/db';

interface TasksViewProps {
  user: AppUser;
  onRefreshUser: () => void;
}

export default function TasksView({ user, onRefreshUser }: TasksViewProps) {
  const [tasks, setTasks] = useState<EarnTask[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Website Visit Task States
  const [activeWebVisitTask, setActiveWebVisitTask] = useState<EarnTask | null>(null);
  const [webVisitStage, setWebVisitStage] = useState<1 | 2 | 3 | 4>(1);
  const [webVisitTimeLeft, setWebVisitTimeLeft] = useState(0);
  const [webVisitScrolledBottom, setWebVisitScrolledBottom] = useState(false);
  const [webVisitStartTime, setWebVisitStartTime] = useState<number>(0);
  const [errorMsg, setErrorMsg] = useState('');

  // Sponsor Ad Task Multi-Stage states
  const [sponsorStage, setSponsorStage] = useState<number>(1);
  const scrollContainerRef = useRef<HTMLDivElement>(null);

  // Timer States
  const [runningTask, setRunningTask] = useState<EarnTask | null>(null);
  const [timeLeft, setTimeLeft] = useState(0);
  const [progress, setProgress] = useState(100);
  const [adTargetURL, setAdTargetURL] = useState('about:blank');
  
  // Screenshot Upload State
  const [selectedTask, setSelectedTask] = useState<EarnTask | null>(null);
  const [imageFile, setImageFile] = useState<string | null>(null);
  const [screenshotName, setScreenshotName] = useState<string>('');
  const [uploading, setUploading] = useState(false);
  const [successMsg, setSuccessMsg] = useState('');
  const [downloadedTasks, setDownloadedTasks] = useState<Record<string, boolean>>({});
  const [activeTimers, setActiveTimers] = useState<Record<string, number>>({});

  useEffect(() => {
    const interval = setInterval(() => {
      setActiveTimers(prev => {
        const next = { ...prev };
        let updated = false;
        for (const taskId of Object.keys(next)) {
          const remaining = next[taskId];
          if (typeof remaining === 'number' && remaining > 0) {
            next[taskId] = remaining - 1;
            updated = true;
          }
        }
        return updated ? next : prev;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);
  
  // Completed/Pending records for the active logged in user
  const [userSubmissions, setUserSubmissions] = useState<TaskSubmission[]>([]);

  useEffect(() => {
    setLoading(true);
    // Subscribe to tasks in real-time
    const unsubscribe = databaseService.subscribeTasks((allTasks) => {
      setTasks(allTasks);
      setLoading(false);
    });

    fetchSubmissions();

    return () => {
      if (typeof unsubscribe === 'function') {
        unsubscribe();
      }
    };
  }, [user.uid]);

  // Handle automatic timer countdown ticks
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (runningTask && timeLeft > 0) {
      interval = setInterval(() => {
        setTimeLeft(prev => {
          const next = prev - 1;
          const total = runningTask.id === 'sponsor_ad_1' ? 3 : (runningTask.duration || 15);
          setProgress((next / total) * 100);
          return next;
        });
      }, 1000);
    } else if (runningTask && timeLeft === 0) {
      if (runningTask.id === 'sponsor_ad_1') {
        // Do nothing automatically; the user must click "কনফার্ম করুন" to proceed
      } else {
        // Countdown completed! Call balance transaction helper
        completeAutomaticTask();
      }
    }
    return () => clearInterval(interval);
  }, [runningTask, timeLeft]);

  const fetchSubmissions = async () => {
    try {
      const allSubs = await databaseService.getSubmissions();
      const userSubs = allSubs.filter(s => s.userId === user.uid);
      setUserSubmissions(userSubs);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchTasksAndSubmissions = async () => {
    // Left for backward compatibility and manual updates
    await fetchSubmissions();
  };

  // Anti-Cheat for Automatic / Sponsor Ad Tasks
  useEffect(() => {
    if (!runningTask) return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        // User cheated by minimizing or leaving tab
        setRunningTask(null);
        if (runningTask.id === 'sponsor_ad_1') {
          setErrorMsg("টাস্ক বাতিল! সম্পূর্ণ নিয়ম মেনে সময় শেষ করুন। ❌");
        } else {
          setErrorMsg("টাস্ক বাতিল! সম্পূর্ণ সময় পেজে থাকতে হবে। ❌");
        }
        setTimeout(() => setErrorMsg(''), 5000);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [runningTask]);

  // Launch Automatic countdown
  const startAutomaticTask = (task: EarnTask) => {
    if (task.claimedBy.includes(user.uid) || runningTask) return;
    setRunningTask(task);
    setTimeLeft(task.id === 'sponsor_ad_1' ? 3 : (task.duration || 15));
    setProgress(100);

    // Reset sponsor task state
    if (task.id === 'sponsor_ad_1') {
      setSponsorStage(1);
    }

    const targetLink = task.id === 'sponsor_ad_1' 
      ? (task.targetUrl || 'https://uniquemoviebd.blogspot.com') 
      : (task.targetUrl || (task as any).link || 'about:blank');
    setAdTargetURL(targetLink);
  };

  const toBanglaDigit = (num: number) => {
    const banglaDigits = ['০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'];
    return num.toFixed(2).replace(/\d/g, d => banglaDigits[parseInt(d)]);
  };

  // Triggers transactions on atomic countdown completion
  const completeAutomaticTask = async () => {
    if (!runningTask) return;
    try {
      const rewardAmt = runningTask.id === 'sponsor_ad_1' ? (runningTask.reward || 0.20) : runningTask.reward;
      await databaseService.claimAutomaticTask(user.uid, runningTask.id, rewardAmt);
      
      // Spec requirement:
      // Upon successful completion (timer reaches 0), perform secure Firestore database transaction to add exactly ৳০.২০...
      // and flash celebration: "টাকা সফলভাবে আপনার ব্যালেন্সে যোগ করা হয়েছে! ৳০.২০ + 💸"
      if (runningTask.id === 'sponsor_ad_1') {
        setSuccessMsg(`টাকা সফলভাবে আপনার ব্যালেন্সে যোগ করা হয়েছে! ৳${toBanglaDigit(rewardAmt)} + 💸`);
      } else {
        setSuccessMsg(`টাকা সফলভাবে আপনার ব্যালেন্সে যোগ করা হয়েছে! ৳${runningTask.reward.toFixed(2)} + 💸`);
      }
      setTimeout(() => setSuccessMsg(''), 5000);
      onRefreshUser();
      await fetchTasksAndSubmissions();
    } catch (err) {
      console.error(err);
    } finally {
      setRunningTask(null);
    }
  };

  // Launch Website Visit Task Routine Setup
  const handleStartWebVisitTask = (task: EarnTask) => {
    if (task.claimedBy.includes(user.uid) || activeWebVisitTask || runningTask) return;
    
    // Set active task and reset sequence variables
    setActiveWebVisitTask(task);
    setWebVisitStage(1);
    setWebVisitTimeLeft(task.duration || 15);
    setWebVisitScrolledBottom(false);
    setWebVisitStartTime(performance.now());
  };

  // Website Visit Stage timer control countdown
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeWebVisitTask && webVisitTimeLeft > 0) {
      interval = setInterval(() => {
        setWebVisitTimeLeft(prev => {
          const next = prev - 1;
          if (next === 0) {
            if (webVisitStage === 1) {
              setWebVisitStage(2);
              setWebVisitScrolledBottom(false);
            } else if (webVisitStage === 3) {
              setWebVisitStage(4);
              setWebVisitScrolledBottom(false);
              return activeWebVisitTask.duration || 15;
            }
          }
          return next;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [activeWebVisitTask, webVisitTimeLeft, webVisitStage]);

  // Anti-Cheat App Minimization / Tab Switch listener
  useEffect(() => {
    if (!activeWebVisitTask) return;

    const handleVisibilityChange = () => {
      if (document.hidden) {
        // User cheated by minimizing or leaving tab
        setActiveWebVisitTask(null);
        setErrorMsg("টাস্ক বাতিল হয়েছে! আপনাকে সম্পূর্ণ সময় পেজে থাকতে হবে। ❌");
        setTimeout(() => setErrorMsg(''), 6000);
      }
    };

    document.addEventListener('visibilitychange', handleVisibilityChange);
    return () => {
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [activeWebVisitTask]);

  // Finish webpage visit task sequence
  const completeWebVisitTask = async () => {
    if (!activeWebVisitTask) return;
    
    const elapsed = (performance.now() - webVisitStartTime) / 1000;
    const required = (activeWebVisitTask.duration || 15) * 3;
    
    // Fallback tamper/clock check
    if (elapsed < required - 2) {
      setActiveWebVisitTask(null);
      setErrorMsg("টাস্ক বাতিল হয়েছে! আপনাকে সম্পূর্ণ সময় পেজে থাকতে হবে। ❌");
      setTimeout(() => setErrorMsg(''), 6000);
      return;
    }

    try {
      await databaseService.claimAutomaticTask(user.uid, activeWebVisitTask.id, activeWebVisitTask.reward);
      setSuccessMsg(`অভিনন্দন! "${activeWebVisitTask.title}" সফলভাবে সম্পন্ন হয়েছে এবং ৳${activeWebVisitTask.reward.toFixed(2)} আপনার ব্যালেন্সে যোগ হয়েছে!`);
      setTimeout(() => setSuccessMsg(''), 5000);
      onRefreshUser();
      await fetchTasksAndSubmissions();
    } catch (err) {
      console.error(err);
      setErrorMsg("টাস্ক সমাপ্ত করতে সমস্যা হয়েছে!");
      setTimeout(() => setErrorMsg(''), 4000);
    } finally {
      setActiveWebVisitTask(null);
    }
  };

  const handleStartManualTaskLink = (task: EarnTask) => {
    const url = task.targetUrl || (task as any).link;
    if (url) {
      window.open(url, '_blank', 'noopener,noreferrer');
    }
    setSelectedTask(task);
    if (activeTimers[task.id] === undefined) {
      const requiredDuration = task.duration || 60;
      setActiveTimers(prev => ({ ...prev, [task.id]: requiredDuration }));
    }
  };

  // Drag and Drop Base64 conversion
  const handleImageUploadChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      setScreenshotName(file.name);
      const reader = new FileReader();
      reader.onload = () => {
        setImageFile(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Submit manual challenge screenshot
  const submitManualTaskScreenshot = async () => {
    if (!selectedTask || !imageFile) return;
    setUploading(true);
    try {
      await databaseService.submitManualTask(
        user.uid,
        user.email,
        selectedTask.title,
        selectedTask.id,
        selectedTask.reward,
        imageFile
      );
      setSuccessMsg('আপনার স্ক্রিনশটটি সফলভাবে সুপার এডমিন প্যানেলে পাঠানো হয়েছে। রিভিউ হতে ১০-৩০ মিনিট সময় লাগতে পারে।');
      setTimeout(() => setSuccessMsg(''), 5000);
      setImageFile(null);
      setScreenshotName('');
      setSelectedTask(null);
      await fetchTasksAndSubmissions();
    } catch (err) {
      console.error(err);
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6">
      {/* Active Success Notification */}
      <AnimatePresence>
        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 rounded-xl bg-neon-green/10 border border-neon-green/30 text-neon-green flex items-center gap-3 shadow-md"
          >
            <CheckCircle className="shrink-0 animate-bounce" size={22} />
            <span className="text-sm font-semibold">{successMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Active Error Notification */}
      <AnimatePresence>
        {errorMsg && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-500 flex items-center gap-3 shadow-md"
          >
            <AlertCircle className="shrink-0 animate-pulse text-red-500" size={22} />
            <span className="text-sm font-semibold">{errorMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Countdown Timer Immersive Full-Screen Ad Section Overlay */}
      <AnimatePresence>
        {runningTask && (
          <motion.div
            initial={{ opacity: 0, y: '100%' }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 180 }}
            className={
              runningTask.id === 'sponsor_ad_1'
                ? "fixed top-0 left-0 w-screen h-screen bg-black/95 z-[9999] flex flex-col p-0 m-0 overflow-hidden"
                : "fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex flex-col justify-between p-4 md:p-6"
            }
          >
            {/* Top Header Layer in the Modal */}
            <div 
              style={runningTask.id === 'sponsor_ad_1' ? { height: '80px', width: '100%', margin: 0 } : undefined}
              className={
                runningTask.id === 'sponsor_ad_1'
                  ? "bg-[#111418] border-b border-gray-800 flex items-center justify-between px-4 md:px-6 shadow-md font-sans w-full shrink-0 m-0 rounded-none h-[80px]"
                  : "bg-[#111418] border border-gray-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl mb-4 font-sans max-w-5xl mx-auto w-full"
              }
            >
              <div className="flex items-center gap-3 min-w-0">
                <button
                  onClick={() => setRunningTask(null)}
                  className="p-1.5 px-3 rounded-lg bg-gray-900 border border-gray-800 text-gray-400 hover:text-white hover:bg-red-500/10 transition-all font-sans text-[10px] font-bold cursor-pointer shrink-0"
                >
                  ✕ বাতিল (Cancel)
                </button>
                <div className="p-2 bg-neon-green/10 text-neon-green rounded-xl animate-pulse shrink-0 hidden sm:block">
                  <Play className="text-neon-green fill-neon-green" size={20} />
                </div>
                <div className="block min-w-0">
                  <div className="flex items-center gap-1.5 text-[9px] md:text-[10px] text-gray-400 font-mono">
                    <span className="text-neon-green">● SPONSOR AD_PORTAL</span>
                  </div>
                  <div className="font-mono text-xs text-white font-bold truncate max-w-[120px] sm:max-w-xs">
                    {runningTask.title}
                  </div>
                </div>
              </div>

              {/* Secure Countdown & Stage Instruction Banner */}
              <div className="flex items-center justify-center gap-2 shrink-0 max-w-md md:max-w-xl">
                {runningTask.id === 'sponsor_ad_1' ? (
                  timeLeft > 0 ? (
                    <div className="flex items-center gap-2 bg-red-950/20 border border-red-500/20 px-3 py-1.5 md:py-2 rounded-xl">
                      <span className="w-1.5 h-1.5 rounded-full bg-red-500 animate-ping shrink-0" />
                      <span className="font-bold text-[10px] md:text-xs text-red-400 font-sans leading-none text-center">
                        বিজ্ঞাপনটির নিচে স্ক্রোল করুন এবং যেকোনো ১টি বিজ্ঞাপনে ক্লিক করুন (লোড হচ্ছে... {timeLeft}s) ⏳
                      </span>
                    </div>
                  ) : (
                    <button
                      onClick={completeAutomaticTask}
                      className="px-5 py-2 md:py-2.5 bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 active:scale-[98] transition-all text-white font-black text-[11px] md:text-xs rounded-xl shadow-[0_0_15px_rgba(16,185,129,0.4)] hover:shadow-[0_0_25px_rgba(16,185,129,0.75)] cursor-pointer flex items-center gap-1 animate-bounce"
                    >
                      টাস্ক সম্পূর্ণ করুন (Confirm) 💸
                    </button>
                  )
                ) : (
                  <div className="flex items-center justify-center gap-2 bg-gray-900/85 px-3 md:px-5 py-1.5 md:py-2.5 rounded-xl border border-neon-green/20">
                    <span className="font-bold text-xs md:text-sm text-white font-sans text-center">
                      <>বিজ্ঞাপনটি দেখুন: <span className="text-neon-green font-mono text-base">{timeLeft}</span> সেকেন্ড বাকি... ⏳</>
                    </span>
                    <span className={`w-2 h-2 rounded-full bg-neon-green ${timeLeft > 0 ? 'animate-ping' : ''}`} />
                  </div>
                )}
              </div>

              {/* Progress Indicator - only show for normal tasks */}
              {runningTask.id !== 'sponsor_ad_1' && (
                <div className="w-full md:w-48 bg-gray-850 h-2 rounded-full overflow-hidden shrink-0">
                  <div 
                    className="bg-neon-green h-full transition-all duration-1000 ease-linear"
                    style={{ width: `${(timeLeft / (runningTask.duration || 15)) * 100}%` }}
                  />
                </div>
              )}
            </div>

            {/* Interactive Sandbox Web Content Viewer Container */}
            <div 
              ref={scrollContainerRef}
              className={
                runningTask.id === 'sponsor_ad_1'
                  ? "flex-1 bg-white relative shadow-inner overflow-hidden w-full max-w-none rounded-none border-0 m-0 p-0"
                  : "flex-1 bg-white border border-gray-850 rounded-2xl max-w-5xl mx-auto w-full relative shadow-inner overflow-y-auto"
              }
            >
              <div className={runningTask.id === 'sponsor_ad_1' ? "w-full h-full" : "w-full h-full min-h-[600px] relative"}>
                {adTargetURL && adTargetURL !== 'about:blank' ? (
                  <iframe
                    id="premium-ad-iframe"
                    src={adTargetURL}
                    title="Sponsor Premium Ad"
                    className="w-full border-x-0 border-b-0"
                    style={{
                      width: '100% !important',
                      height: '100% !important',
                      minHeight: runningTask.id === 'sponsor_ad_1' ? 'calc(100vh - 80px)' : '650px',
                      border: 'none',
                    }}
                    sandbox="allow-scripts allow-same-origin allow-popups"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="absolute inset-0 flex flex-col items-center justify-center p-8 bg-gradient-to-br from-gray-50 to-gray-150 text-center font-sans">
                    <div className="max-w-md space-y-6">
                      <div className="w-16 h-16 bg-neon-green/10 text-neon-green rounded-full flex items-center justify-center mx-auto animate-bounce">
                        <Play className="text-neon-green" size={32} />
                      </div>
                      <div className="space-y-2">
                        <span className="text-[10px] font-bold text-gray-400 tracking-widest uppercase block">SPONSORED PROMOTION PORTAL</span>
                        <h4 className="font-display font-black text-xl text-gray-950">EarnHub Verified Digital Sponsor Campaign</h4>
                        <p className="text-xs text-gray-650 leading-relaxed font-semibold">
                          বিজ্ঞপনদাতার সাইটটি লোড হচ্ছে। আপনার আইপি এড্রেস এবং ভিউয়ার আইডি ট্র্যাকিং করা হচ্ছে। কাউন্টডাউন শেষ হওয়া পর্যন্ত অনুগ্রহ করে এই সেকশনে অপেক্ষা করুন।
                        </p>
                      </div>
                      <div className="p-4 bg-white border border-gray-200 rounded-xl flex items-center justify-between text-left shadow-sm">
                        <div>
                          <p className="text-[10px] text-gray-400 font-bold uppercase">Estimated Credit</p>
                          <p className="text-sm font-bold text-gray-900 font-mono">৳{runningTask.reward.toFixed(2)} BDT</p>
                        </div>
                        <div className="text-right">
                          <p className="text-[10px] text-gray-450 font-bold uppercase">Reward Security</p>
                          <span className="text-[10px] font-bold bg-emerald-50 text-emerald-600 px-2 py-0.5 rounded">100% Guaranteed</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            </div>

          </motion.div>
        )}
      </AnimatePresence>

      {/* Manual Screenshot Submit Form Drawer */}
      <AnimatePresence>
        {selectedTask && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="fixed inset-0 bg-black/75 backdrop-blur-sm z-40 flex items-center justify-center p-4"
          >
            <motion.div
              initial={{ scale: 0.95, y: 15 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.95, y: 15 }}
              className="bg-[#12161a] border border-gray-800 rounded-2xl p-6 max-w-lg w-full text-left"
            >
              <div className="flex justify-between items-center mb-4">
                <h4 className="font-display font-bold text-lg text-white">
                  টাস্ক প্রুফ সাবমিট করুন
                </h4>
                <button
                  onClick={() => { setSelectedTask(null); setImageFile(null); }}
                  className="text-gray-400 hover:text-white text-xs px-2.5 py-1 rounded-lg bg-gray-900 border border-gray-800"
                >
                  বাতিল করুন
                </button>
              </div>

              <div className="p-3.5 bg-neon-green/5 border border-neon-green/20 rounded-xl mb-4 text-xs text-gray-300">
                <span className="font-bold text-neon-green">টাস্ক নেম:</span> {selectedTask.title} <br />
                <span className="font-bold text-neon-green">রিওয়ার্ড ব্যালেন্স:</span> ৳{selectedTask.reward.toFixed(2)} টাকা
                {(selectedTask.targetUrl || (selectedTask as any).link) && (
                  <div className="mt-2.5">
                    <a
                      href={selectedTask.targetUrl || (selectedTask as any).link}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-neon-green font-bold text-black text-[11px] hover:brightness-110 transition-all cursor-pointer"
                    >
                      কাজের লিংকে যান (Open Link)
                    </a>
                  </div>
                )}
              </div>

               {activeTimers[selectedTask.id] > 0 ? (
                 <div className="p-6 border border-amber-500/20 bg-amber-500/5 rounded-xl text-center space-y-3">
                   <div className="text-3xl font-mono font-bold text-amber-400 select-none animate-pulse">
                     {activeTimers[selectedTask.id]}s ⏳
                   </div>
                   <p className="text-xs text-amber-300 font-semibold leading-relaxed">
                     দয়া করে লিংকে আরও <span className="font-mono text-white text-sm bg-black/40 px-1.5 py-0.5 rounded">{activeTimers[selectedTask.id]}</span> সেকেন্ড অপেক্ষা করুন! ⏳
                   </p>
                   <p className="text-[10px] text-gray-500">
                     লিংকে সঠিক সময় অপেক্ষা শেষ হলে এই পেজে স্বয়ংক্রিয়ভাবে স্ক্রিনশট আপলোড অপশন আনলক হবে।
                   </p>
                 </div>
               ) : (
                 <>
                   {/* Image Input Container */}
                   <div className="border-2 border-dashed border-gray-800 hover:border-neon-green/30 rounded-xl p-6 text-center cursor-pointer relative bg-gray-950/40 hover:bg-gray-950/80 transition-all">
                     <input
                       id="screenshot-file-picker"
                       type="file"
                       accept="image/*"
                       onChange={handleImageUploadChange}
                       className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                     />
                     
                     {imageFile ? (
                       <div className="space-y-3">
                         <img src={imageFile} alt="Preview" className="max-h-40 mx-auto rounded-lg border border-gray-800" />
                         <p className="text-xs text-neon-green font-mono truncate">{screenshotName}</p>
                         <p className="text-[10px] text-gray-500">পরিবর্তন করতে পুনরায় ক্লিক বা ড্র্যাগ করুন</p>
                       </div>
                     ) : (
                       <div className="space-y-2.5">
                         <div className="p-3 bg-neon-green/10 text-neon-green rounded-full w-fit mx-auto">
                           <UploadCloud size={24} />
                         </div>
                         <div>
                           <p className="text-xs font-bold text-slate-100">ডাউনলোডের স্ক্রিনশট জমা দিন</p>
                           <p className="text-[10px] text-gray-500 mt-1">PNG, JPG formats accepted (Max 5MB)</p>
                         </div>
                       </div>
                     )}
                   </div>

                   <button
                     id="submit-screenshot-btn"
                     disabled={!imageFile || uploading}
                     onClick={submitManualTaskScreenshot}
                     className={`w-full mt-5 py-3 rounded-xl font-bold font-display text-sm flex items-center justify-center gap-2 transition ${
                       imageFile && !uploading
                         ? 'bg-neon-green text-black hover:neon-btn-glow cursor-pointer'
                         : 'bg-gray-800 text-gray-500 cursor-not-allowed'
                     }`}
                   >
                     {uploading ? 'পাঠানো হচ্ছে...' : 'অনুমোদনের জন্য স্ক্রিনশট জমা দিন'}
                   </button>
                 </>
               )}
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Website Visit Task Immersive Browser Overlay */}
      <AnimatePresence>
        {activeWebVisitTask && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 backdrop-blur-md z-50 flex flex-col justify-between p-4 md:p-6"
          >
            {/* Top Bar with URL & Stage Counter */}
            <div className="bg-[#111418] border border-gray-800 rounded-2xl p-4 flex flex-col md:flex-row md:items-center justify-between gap-4 shadow-xl mb-4 font-sans max-w-5xl mx-auto w-full">
              <div className="flex items-center gap-3 w-full md:w-auto">
                <div className="p-2 bg-sky-500/10 text-sky-400 rounded-xl">
                  <Globe className="text-sky-400" size={20} />
                </div>
                <div className="block min-w-0 flex-1">
                  <div className="flex items-center gap-1.5 text-[10px] text-gray-500 font-mono">
                    <span className="text-emerald-400">● SECURE AD PARTNER CONNECTION</span>
                    <span>|</span>
                    <span className="flex items-center gap-1"><Lock size={10} /> HTTPS Verified</span>
                  </div>
                  <div className="font-mono text-xs text-sky-400 font-bold truncate max-w-full">
                    {activeWebVisitTask.targetUrl}
                    {webVisitStage > 2 ? '/blog/article-verification-id-8274a' : ''}
                  </div>
                </div>
              </div>

              {/* Countdown / Stage Display State */}
              <div className="flex items-center justify-between md:justify-start gap-3 bg-gray-900/60 px-4 py-2.5 rounded-xl border border-gray-800 shrink-0 w-full md:w-auto">
                <span className="font-bold text-xs text-white">
                  {webVisitStage === 1 && `ধাপ ১/৩: পৃষ্ঠা ভেরিফাই হচ্ছে... (⏱️ ${webVisitTimeLeft}s)`}
                  {webVisitStage === 2 && 'ধাপ ১/৩ সম্পন্ন! দয়া করে নিচে স্ক্রোল করুন 👇'}
                  {webVisitStage === 3 && `ধাপ ২/৩: পরবর্তী পৃষ্ঠা লোড হচ্ছে... (⏱️ ${webVisitTimeLeft}s)`}
                  {webVisitStage === 4 && (webVisitTimeLeft > 0 ? `ধাপ ৩/৩: কন্টেন্ট ব্রাউজ করুন... (⏱️ ${webVisitTimeLeft}s)` : 'টাস্ক সম্পন্ন! 💰')}
                </span>
                
                {/* Visual indicator if timer is running */}
                {(webVisitStage !== 2 && webVisitTimeLeft > 0) && (
                  <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse" />
                )}
                {(webVisitStage === 4 && webVisitTimeLeft === 0) && (
                  <span className="w-2.5 h-2.5 rounded-full bg-neon-green" />
                )}
              </div>

              {/* Cancel Button */}
              <button
                onClick={() => {
                  setActiveWebVisitTask(null);
                  setErrorMsg('ডিভাইস ক্যান্সেলেশনে টাস্ক বাতিল হয়েছে! ❌');
                  setTimeout(() => setErrorMsg(''), 5000);
                }}
                className="px-4 py-2.5 rounded-xl text-xs font-bold bg-red-650 hover:bg-red-500 text-white transition cursor-pointer shrink-0 w-full md:w-auto text-center font-sans tracking-wide"
              >
                টাস্ক বাতিল করুন (Cancel Task)
              </button>
            </div>

            {/* Simulated Web View Container */}
            <div 
              onScroll={(e) => {
                const target = e.currentTarget;
                const isAtBottom = target.scrollHeight - target.scrollTop <= target.clientHeight + 45;
                if (isAtBottom) {
                  setWebVisitScrolledBottom(true);
                }
              }}
              className="flex-1 bg-white text-[#111418] border border-gray-850 rounded-2xl overflow-y-auto max-w-5xl mx-auto w-full relative p-6 md:p-8 space-y-6 shadow-inner"
            >
              {/* Header inside Partner News */}
              <div className="border-b-2 border-gray-100 pb-5 text-center">
                <span className="text-[10px] font-bold text-blue-600 tracking-wider uppercase bg-blue-50 px-2.5 py-1 rounded">SPONSOR PARTNER PORTAL</span>
                <h1 className="font-display font-black text-xl md:text-2xl text-gray-900 mt-3.5 leading-tight">
                  {webVisitStage <= 2 
                    ? "অনলাইন পার্টনার রিওয়ার্ড প্ল্যাটফর্ম ব্যবহার করে সহজ ইনকাম করার আসল উপায়!" 
                    : "ধাপ ২: ডিজিটাল অ্যাড নেটওয়ার্ক এবং স্পনসরড কন্টেন্ট কীভাবে কাজ করে?"}
                </h1>
                <p className="text-[10px] text-gray-400 mt-2 font-mono font-bold">Published on June 2, 2026 • Verified Partner Advertiser</p>
              </div>

              {/* Dynamic scroll indicator banner */}
              {webVisitStage === 2 && !webVisitScrolledBottom && (
                <div className="sticky top-0 bg-blue-650 text-white p-3 rounded-xl text-xs font-bold text-center flex items-center justify-center gap-2 animate-bounce shadow-md">
                  <span>দয়া করে নিচে স্ক্রোল করুন এবং "পরবর্তী ধাপ" বাটনে ক্লিক করুন! 👇</span>
                </div>
              )}

              {/* Article Content Paragraphs */}
              <div className="space-y-4 text-xs md:text-sm text-gray-700 leading-relaxed max-w-3xl mx-auto font-sans font-medium">
                <p className="font-semibold text-gray-950">
                  বর্তমান তথ্য প্রযুক্তির যুগে অনলাইনের মাধ্যমে ঘরে বসে পার্ট টাইম রিওয়ার্ড আর্ন করা এখন অনেক সহজ মাধ্যম হয়ে দাঁড়িয়েছে। কিন্তু অধিকাংশ ইউজার সঠিক ও নির্ভরযোগ্য গাইডলাইন না পাওয়ায় প্রতারণার শিকার হন।
                </p>
                <div className="my-4 p-4 bg-gray-55 border-l-4 border-blue-500 rounded-xl space-y-2">
                  <span className="text-[9px] font-bold text-blue-600 tracking-wider uppercase block">SPONSORED CAMPAIGN HIGHLIGHTS</span>
                  <p className="text-xs text-gray-650 leading-relaxed font-semibold">
                    আমাদের স্পন্সর পার্টনারদের সৌজন্যে আপনি এই আর্টিকেলটি দেখছেন। এই টাস্কটির মাধ্যমে আপনি সহজেই ব্যালেন্স সংগ্রহ করতে পারছেন, কারণ স্পন্সররা আমাদের এই পৃষ্ঠাটি ভিউ করার জন্য পেআউট প্রদান করে থাকে।
                  </p>
                </div>
                <p>
                  ডিজিটাল মার্কেটিং এবং অ্যাড নেটওয়ার্কগুলো সাধারণত ব্যবহারকারীর দৃষ্টি আকর্ষণ করার পরিমাপক হিসেবে "টাইম অন সাইট" বা সময়কে ব্যবহার করে থাকে। এর ফলে ব্যবহারকারী যত বেশি সময় পেজে কাটাবে, ডোমেইনের অথরিটি এবং বিজ্ঞাপনদাতাদের কনভার্সন রেট তত উন্নত হবে।
                </p>
                <p className="border-t border-gray-150 pt-4">
                  আর্টিকেলটির দ্বিতীয় অংশে আমরা মূলত দেখবো কীভাবে সিকিউর পেমেন্ট গেটওয়ে এবং আর্নিং সেকশনগুলোর রিয়েল টাইম ডিস্ট্রিবিউশন মডেল কাজ করে। নিচে স্ক্রোল করে সেই অংশে ভিজিট করুন।
                </p>

                {/* Simulated Partner Image / Promo Graphic Card */}
                <div className="w-full bg-gradient-to-r from-blue-600 to-indigo-700 p-6 rounded-2xl text-white space-y-3 shadow-md my-6 selection:bg-indigo-300 select-all">
                  <h3 className="font-bold text-base">🚀 EarnHub Pro Sponsored Campaign</h3>
                  <p className="text-xs text-blue-105 leading-relaxed">
                    এই ওয়েবসাইট ভিজিট টাস্কটি কমপ্লিট করলে আপনার মেইন ব্যালেন্সে ৳{activeWebVisitTask?.reward?.toFixed(2) || '0.00'} টাকা সাথে সাথে যোগ হবে। আপনার আইপি এবং ব্রাউজিং হিস্টোরি রিয়েল-টাইম অটো সাবমিট হয়ে যাবে। অন্য টැබে চলে গেলে টাস্ক বাতিল হতে পারে।
                  </p>
                  <div className="flex gap-2">
                    <span className="text-[9px] bg-white/20 px-2.5 py-1 rounded font-semibold">100% SECURE</span>
                    <span className="text-[9px] bg-white/20 px-2.5 py-1 rounded font-semibold">INSTANT Payout</span>
                  </div>
                </div>

                <p>
                  অ্যাকাউন্ট ভেরিফিকেশন করার জন্য একটি নির্দিষ্ট নিয়মাবলী মেনে চলতে হয়। বানান ভুল জিমেইল প্রদান করলে পেমেন্ট রিজেক্ট হতে পারে। তাই সব সময় আপনার জিমেইল সঠিকভাবে ইনপুট দিন যাতে কোনো ধরনের টেকনিক্যাল ঝামেলা এড়ানো সম্ভব হয়।
                </p>
                <p>
                  এই শেষ ধাপে, অনুগ্রহ করে আর্টিকেলটির শেষ পর্যন্ত স্ক্রোল করে সম্পূর্ণ তথ্য নিয়ে কাজ করুন। আপনি সফলভাবে সময় শেষ করলে একটি অনন্য ক্লেইম বাটন স্ক্রিনের শেষে আনলক হবে।
                </p>
              </div>

              {/* Bottom Scroll Target Anchor Block */}
              <div className="pt-8 border-t border-gray-100 text-center space-y-4 font-sans">
                <span className="text-xs text-gray-400 block font-bold">--- আর্টিকেলের শেষ অংশ ---</span>
                
                {/* Stage-wise unlock buttons */}
                <div className="max-w-md mx-auto py-2">
                  {webVisitStage === 1 && (
                    <div className="p-4 bg-amber-500/5 border border-amber-500/20 text-amber-600 rounded-xl text-xs font-bold leading-relaxed">
                      ⏳ উপরে চলমান প্রথম {activeWebVisitTask?.duration || 15} সেকেন্ডের টাইমার কাউন্টডাউন শেষ হওয়ার জন্য অপেক্ষা করুন...
                    </div>
                  )}

                  {webVisitStage === 2 && (
                    <>
                      {webVisitScrolledBottom ? (
                        <button
                          onClick={() => {
                            setWebVisitStage(3);
                            setWebVisitTimeLeft(activeWebVisitTask?.duration || 15);
                            setWebVisitScrolledBottom(false);
                          }}
                          className="w-full px-6 py-4 rounded-xl bg-blue-600 text-white font-black text-xs hover:bg-blue-500 hover:scale-[1.02] active:scale-95 transition shadow-lg select-none duration-150 cursor-pointer font-sans"
                        >
                          পরবর্তী ধাপ (Next Step) ➡️
                        </button>
                      ) : (
                        <div className="p-4 bg-blue-50 border border-blue-100 text-blue-600 rounded-xl text-xs font-bold animate-pulse leading-relaxed">
                          👇 নিচে স্ক্রোল করুন পরবর্তী ধাপের বাটন খোলার জন্য! (Scroll down to unlock)
                        </div>
                      )}
                    </>
                  )}

                  {webVisitStage === 3 && (
                    <div className="p-4 bg-amber-500/5 border border-amber-500/20 text-amber-600 rounded-xl text-xs font-bold leading-relaxed">
                      ⏳ অনুগ্রহ করে দ্বিতীয় {activeWebVisitTask?.duration || 15} সেকেন্ডের ভেরিফিকেশন টাইমার শেষ হওয়া পর্যন্ত অপেক্ষা করুন...
                    </div>
                  )}

                  {webVisitStage === 4 && (
                    <>
                      {webVisitTimeLeft > 0 ? (
                        <div className="p-4 bg-sky-50 border border-sky-100 text-sky-600 rounded-xl text-xs font-bold animate-pulse leading-relaxed">
                          ⏳ ব্রাউজিং পিরিয়ড শেষ হওয়ার জন্য অপেক্ষা করুন: আরও {webVisitTimeLeft}s বাকি আছে!
                        </div>
                      ) : (
                        <button
                          onClick={completeWebVisitTask}
                          className="w-full px-6 py-4 rounded-xl bg-[#00e676] text-black font-black text-sm hover:brightness-110 hover:scale-[1.02] active:scale-95 transition shadow-[0_0_25px_rgba(0,230,118,0.5)] select-none animate-bounce cursor-pointer font-sans"
                        >
                          রিওয়ার্ড সংগ্রহ করুন (Collect Reward) 💰 🎉
                        </button>
                      )}
                    </>
                  )}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Main Feature Layout */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-display font-bold text-white tracking-tight">সহজ টাস্ক গাইড এবং আর্ন স্পেস</h2>
          <p className="text-xs text-gray-400 mt-1">অ্যাড দেখে অথবা স্পন্সর গেম চ্যালেঞ্জ পূরণ করে টাকা উপার্জন করুন।</p>
        </div>
        <div className="shrink-0 text-xs bg-[#12161a] border border-gray-800 px-3.5 py-2 rounded-xl text-gray-400">
          আজকের মোট টাস্ক: <span className="font-bold text-neon-green font-mono">{tasks.length}টি</span>
        </div>
      </div>

      {loading ? (
        <div className="text-center py-12 text-gray-500 text-sm">টাস্ক ফিড লোড হচ্ছে...</div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          
          {/* Automatic sponsor watch ad */}
          {tasks.filter(t => t.type === 'automatic').map((task) => {
            const claimed = task.id === 'sponsor_ad_1' ? false : task.claimedBy.includes(user.uid);
            return (
              <div 
                key={task.id}
                className="bg-[#12161a] border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/10">
                      অটোমেটিক ইন্সট্যান্ট ক্রেডিট
                    </span>
                    <span className="text-sm font-mono font-bold text-neon-green">৳{task.reward.toFixed(2)}</span>
                  </div>
                  
                  <h3 className="font-display font-semibold text-base text-white mt-3.5 leading-tight">
                    {task.title}
                  </h3>
                  <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                    {task.description}
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-gray-900 flex items-center justify-between gap-4">
                  <span className="text-[11px] text-gray-500 font-mono flex items-center gap-1.5">
                    <Clock size={13} /> {task.duration} সেকেন্ড
                  </span>

                  {task.soldOut ? (
                    <button disabled className="text-xs font-bold text-red-500 bg-red-950/10 border border-red-500/15 rounded-lg px-4 py-2 flex items-center gap-1 font-sans">
                      স্টক শেষ (Sold Out)
                    </button>
                  ) : claimed ? (
                    <button disabled className="text-xs font-bold text-gray-500 bg-gray-900 border border-gray-800/60 rounded-lg px-4 py-2 flex items-center gap-1">
                      <CheckCircle size={14} className="text-gray-500" /> সম্পন্ন হয়েছে
                    </button>
                  ) : (
                    <button
                      id={`start-auto-task-${task.id}`}
                      onClick={() => startAutomaticTask(task)}
                      className="text-xs font-bold text-black bg-neon-green hover:brightness-115 rounded-lg px-4 py-2 flex items-center gap-1 transition-all cursor-pointer"
                    >
                      <Play size={13} className="fill-black" /> অ্যাড দেখুন
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {/* Manual installation screenshot submission */}
          {tasks.filter(t => t.type === 'manual').map((task) => {
            const hasSub = userSubmissions.find(s => s.taskId === task.id);
            return (
              <div 
                key={task.id}
                className="bg-[#12161a] border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/10">
                      ম্যানুয়াল এডমিন রিভিউ
                    </span>
                    <span className="text-sm font-mono font-bold text-blue-400">৳{task.reward.toFixed(2)}</span>
                  </div>
                  
                  <h3 className="font-display font-semibold text-base text-white mt-3.5 leading-tight">
                    {task.title}
                  </h3>
                  <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                    অ্যাপটি ডাউনলোড করুন, ইনস্টল করুন এবং ডাউনলোডের একটি স্ক্রিনশট নিয়ে এখানে জমা দিন।
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-gray-900 flex items-center justify-between gap-4">
                  <span className="text-[11px] text-gray-500 font-mono flex items-center gap-1.5 animate-pulse">
                    <FileText size={13} /> ১টি স্ক্রিনশট
                  </span>

                  <div className="flex items-center gap-2 flex-wrap">
                    {task.downloadLink && (
                      <a
                        href={task.downloadLink}
                        target="_blank"
                        rel="noopener noreferrer"
                        onClick={() => setDownloadedTasks(prev => ({ ...prev, [task.id]: true }))}
                        className="text-xs font-bold text-black bg-emerald-500 hover:bg-emerald-400 rounded-lg px-3.5 py-2 flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(16,185,129,0.45)] hover:shadow-[0_0_22px_rgba(16,185,129,0.75)] select-none hover:scale-105 active:scale-95 duration-200"
                      >
                        <Download size={13} className="shrink-0" /> অ্যাপ ডাউনলোড করুন
                      </a>
                    )}

                    {hasSub ? (
                      <span className={`text-xs font-bold font-mono px-3 py-1.5 rounded-lg border ${
                        hasSub.status === 'Pending' 
                          ? 'bg-amber-500/5 text-amber-300 border-amber-500/20' 
                          : hasSub.status === 'Approved' 
                          ? 'bg-emerald-500/5 text-emerald-300 border-emerald-500/20' 
                          : 'bg-red-500/5 text-red-300 border-red-500/20'
                      }`}>
                        {hasSub.status === 'Pending' ? 'রিভিউ পেন্ডিং' : hasSub.status === 'Approved' ? `অনুমোদিত (+৳${task.reward.toFixed(2)})` : 'বাতিল করা হয়েছে'}
                      </span>
                    ) : (
                      <button
                        id={`start-manual-task-${task.id}`}
                        onClick={() => handleStartManualTaskLink(task)}
                        className="text-xs font-bold text-white bg-blue-600 hover:bg-blue-500 rounded-lg px-4 py-2 flex items-center gap-1 transition-all cursor-pointer select-none whitespace-nowrap"
                      >
                        <ExternalLink size={13} className="shrink-0" />
                        কাজের লিংকে যান (Open Link)
                      </button>
                    )}
                  </div>
                </div>
              </div>
            );
          })}

          {/* Website Visit sequential task cards list */}
          {tasks.filter(t => t.type === 'web_visit').map((task) => {
            const claimed = task.claimedBy.includes(user.uid);
            return (
              <div 
                key={task.id}
                className="bg-[#12161a] border border-gray-800 rounded-xl p-5 hover:border-gray-700 transition flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-3">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/15">
                      🕸️ সিকিউর ওয়েবসাইট ভিজিট
                    </span>
                    <span className="text-sm font-mono font-bold text-neon-green">৳{task.reward.toFixed(2)}</span>
                  </div>
                  
                  <h3 className="font-display font-semibold text-base text-white mt-3.5 leading-tight">
                    {task.title}
                  </h3>
                  <p className="text-xs text-gray-400 mt-2 leading-relaxed">
                    এই কাজটি ৩টি ক্রমানুযায়ী {task.duration || 15}-সেকেন্ডের ধাপে সম্পূর্ণ করতে হবে (মোট {3 * (task.duration || 15)} সেকেন্ড)। অন্য ট্যাবে গেলে টাস্ক ক্যানসেল হয়ে যাবে।
                  </p>
                </div>

                <div className="mt-5 pt-4 border-t border-gray-900 flex items-center justify-between gap-4 font-sans">
                  <span className="text-[11px] text-gray-500 font-mono flex items-center gap-1.5">
                    <Clock size={13} /> {3 * (task.duration || 15)} সেকেন্ড
                  </span>

                  {claimed ? (
                    <button disabled className="text-xs font-bold text-gray-500 bg-gray-950 border border-gray-900 rounded-lg px-4 py-2 flex items-center gap-1">
                      <CheckCircle size={14} className="text-gray-500" /> সম্পন্ন হয়েছে
                    </button>
                  ) : task.soldOut ? (
                    <button disabled className="text-xs font-bold text-red-500 bg-red-950/20 border border-red-950/30 rounded-lg px-4 py-2 flex items-center gap-1 font-sans">
                      স্টক শেষ (Sold Out)
                    </button>
                  ) : (
                    <button
                      id={`start-web-visit-${task.id}`}
                      onClick={() => handleStartWebVisitTask(task)}
                      className="text-xs font-bold text-black bg-[#00e676] hover:brightness-110 rounded-lg px-4 py-2 flex items-center gap-1.5 transition-all cursor-pointer select-none font-sans"
                    >
                      <Globe size={13} /> ওয়েবসাইট ভিজিট করুন
                    </button>
                  )}
                </div>
              </div>
            );
          })}

        </div>
      )}

      {/* Screenshot Submissions History Logs */}
      {userSubmissions.length > 0 && (
        <div className="mt-8">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-1.5 h-6 bg-blue-500 rounded-full" />
            <h3 className="font-display text-lg font-bold text-white">আপনার রিসেন্ট ম্যানুয়াল সাবমিশন</h3>
          </div>

          <div className="overflow-x-auto rounded-xl border border-gray-800 bg-[#12161a]">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-900/60 border-b border-gray-800 text-xs text-gray-400 font-mono font-medium">
                  <th className="p-3.5">টাস্ক</th>
                  <th className="p-3.5">রিওয়ার্ড</th>
                  <th className="p-3.5">তারিখ</th>
                  <th className="p-3.5">প্রিমিয়াম ভিউ</th>
                  <th className="p-3.5 text-right">স্ট্যাটাস</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-900 text-xs">
                {userSubmissions.map((sub) => (
                  <tr key={sub.id} className="hover:bg-gray-950/20">
                    <td className="p-3.5 font-bold text-white max-w-xs truncate">{sub.taskName}</td>
                    <td className="p-3.5 font-mono text-emerald-400 font-bold">+৳{sub.reward.toFixed(2)}</td>
                    <td className="p-3.5 text-gray-400 font-mono">{new Date(sub.createdAt).toLocaleDateString()}</td>
                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5">
                        <img src={sub.screenshotUrl} className="w-8 h-8 rounded border border-gray-800 object-cover" alt="Thumb" />
                        <span className="text-[10px] text-gray-500 font-mono">আপলোড করা হয়েছে</span>
                      </div>
                    </td>
                    <td className="p-3.5 text-right">
                      <span className={`px-2 py-1 rounded text-[10px] font-bold tracking-wide uppercase ${
                        sub.status === 'Pending' 
                          ? 'bg-amber-400/10 text-amber-400' 
                          : sub.status === 'Approved' 
                          ? 'bg-neon-green/10 text-neon-green' 
                          : 'bg-red-500/10 text-red-400'
                      }`}>
                        {sub.status === 'Pending' ? 'পেন্ডিং' : sub.status === 'Approved' ? 'অনুমোদিত' : 'বাতিল'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
