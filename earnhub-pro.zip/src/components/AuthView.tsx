import React, { useState, useRef, useEffect } from 'react';
import { Mail, ArrowRight, ShieldCheck, Coins, Users, UserCheck, Lock, User, Smartphone, MessageCircle } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { authService } from '../services/db';
import { AppUser } from '../types';

interface AuthViewProps {
  onSuccess: (user: AppUser) => void;
}

export default function AuthView({ onSuccess }: AuthViewProps) {
  const [mode, setMode] = useState<'login' | 'register'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  
  // Register specific fields
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [referralCodeEntered, setReferralCodeEntered] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');
  const [toast, setToast] = useState<{ text: string; type: 'login' | 'register' } | null>(null);

  // Secure admin hold states
  const [holdProgress, setHoldProgress] = useState(0); 
  const [adminAccessEnabled, setAdminAccessEnabled] = useState(false);
  const timerRef = useRef<any>(null);
  const intervalRef = useRef<any>(null);

  const startPress = (e: React.MouseEvent | React.TouchEvent) => {
    // Prevent default context menus on mobile devices
    if (e.cancelable) {
      e.preventDefault();
    }
    setHoldProgress(0);
    setErrorMsg('');

    let progress = 0;
    intervalRef.current = setInterval(() => {
      progress += (100 / 40); // 100% divided by 40 steps (40 * 100ms = 4000ms)
      if (progress >= 100) {
        progress = 100;
        clearInterval(intervalRef.current);
      }
      setHoldProgress(progress);
    }, 100);

    timerRef.current = setTimeout(() => {
      clearInterval(intervalRef.current);
      setHoldProgress(100);
      setAdminAccessEnabled(true);
      setMode('login');
      setEmail('');
      setPassword('');
      setToast({ text: "সুপার এডমিন এক্সেস মোড অ্যাক্টিভেট হয়েছে! 🛡️", type: 'login' });
      setTimeout(() => setToast(null), 3000);
    }, 4000);
  };

  const endPress = () => {
    if (timerRef.current) {
      clearTimeout(timerRef.current);
      timerRef.current = null;
    }
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    setHoldProgress(0);
  };

  // Safe cleanup on unmount
  useEffect(() => {
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    
    const cleanEmail = email.trim();
    if (!cleanEmail) {
      setErrorMsg('দয়া করে একটি সঠিক ইমেল এড্রেস টাইপ করুন!');
      return;
    }

    if (mode === 'register') {
      if (!fullName.trim()) {
        setErrorMsg('অনুগ্রহ করে আপনার পুরো নামটি লিখুন!');
        return;
      }
      if (!phoneNumber.trim()) {
        setErrorMsg('অনুগ্রহ করে আপনার মোবাইল নাম্বারটি টাইপ করুন!');
        return;
      }
      if (password.length < 6) {
        setErrorMsg('পাসওয়ার্ড কমপক্ষে ৬ অক্ষরের হতে হবে!');
        return;
      }
      if (password !== confirmPassword) {
        setErrorMsg('পাসওয়ার্ড মিলছে না! দয়া করে একই পাসওয়ার্ড কনফার্ম ফিল্ডে টাইপ করুন।');
        return;
      }
    } else {
      if (!password) {
        setErrorMsg('অনুগ্রহ করে আপনার পাসওয়ার্ডটি টাইপ করুন!');
        return;
      }
    }

    setLoading(true);
    try {
      if (mode === 'register') {
        const newUser = await authService.signUp(
          cleanEmail, 
          referralCodeEntered || undefined,
          fullName.trim(),
          phoneNumber.trim(),
          password
        );
        
        // Trigger register success animation & toast
        setToast({ text: "রেজিস্ট্রেশন সফল হয়েছে! 🎉", type: 'register' });
        
        // Ensure welcome modal pops up inside new session
        sessionStorage.removeItem('earnhub_welcome_seen');
        
        setTimeout(() => {
          setToast(null);
          onSuccess(newUser);
        }, 2200);
      } else {
        const loggedInUser = await authService.signIn(cleanEmail, password);
        
        // Trigger login success animation & toast
        const isAdminLogin = cleanEmail.toLowerCase() === 'bristysadia10@gmail.com';
        setToast({ 
          text: isAdminLogin ? "এডমিন লগইন সফল হয়েছে! 🛡️" : "লগইন সাকসেসফুলি হয়েছে! 🔐", 
          type: 'login' 
        });
        
        setTimeout(() => {
          setToast(null);
          onSuccess(loggedInUser);
        }, 1700);
      }
    } catch (err: any) {
      if (err instanceof Error) {
        setErrorMsg(err.message);
      } else {
        setErrorMsg('প্রবেশ করতে সমস্যা হয়েছে, অনুগ্রহ করে সঠিক তথ্য দিয়ে আবার চেষ্টা করুন।');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleQuickPreset = async (presetEmail: string) => {
    setLoading(true);
    setErrorMsg('');
    try {
      const loggedInUser = await authService.signIn(presetEmail, "EarnHub@123");
      
      // Trigger login success animation
      setToast({ text: "লগইন সাকসেসফুলি হয়েছে! 🔐", type: 'login' });
      
      setTimeout(() => {
        setToast(null);
        onSuccess(loggedInUser);
      }, 1500);
    } catch (err: any) {
      if (err instanceof Error) {
        setErrorMsg(err.message);
      } else {
        setErrorMsg('প্রিসেট লগইন ব্যর্থ হয়েছে।');
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md w-full mx-auto bg-[#12161a] border border-gray-800 rounded-2xl overflow-hidden shadow-2xl mt-10 relative">
      <div className="h-1.5 w-full bg-gradient-to-r from-emerald-500 via-neon-green to-teal-400 font-mono text-[1px]">
        {/* Visual admin press feedback line */}
        {holdProgress > 0 && (
          <div 
            className="h-full bg-neon-green transition-all duration-100 shadow-[0_0_10px_#00E676]" 
            style={{ width: `${holdProgress}%` }} 
          />
        )}
      </div>
      
      {/* Toast Alert Pop-up Notification Banner */}
      <AnimatePresence>
        {toast && (
          <motion.div
            initial={{ opacity: 0, scale: 0.9, y: -20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.9, y: -10 }}
            className="absolute top-4 left-4 right-4 z-50 rounded-xl bg-gray-950 border border-neon-green/30 p-4 shadow-[0_15px_30px_rgba(0,230,118,0.2)] flex items-center gap-3"
          >
            <div className="p-2.5 rounded-lg bg-neon-green/10 text-neon-green">
              <UserCheck size={20} />
            </div>
            <div className="flex-1 text-left">
              <h4 className="font-sans font-bold text-sm text-white">{toast.text}</h4>
              <p className="text-[10px] text-gray-400">ব্যালেন্স ফিনান্সিয়াল ড্যাশবোর্ডে রিডাইরেক্ট করা হচ্ছে...</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="p-6 md:p-8 space-y-6">
        {/* Branding header with Secret 4 second holding triggers */}
        <div 
          className="text-center space-y-2 select-none cursor-pointer group relative"
          onMouseDown={startPress}
          onMouseUp={endPress}
          onMouseLeave={endPress}
          onTouchStart={startPress}
          onTouchEnd={endPress}
        >
          <div 
            className={`p-3 bg-neon-green/10 text-neon-green rounded-2xl w-fit mx-auto border transition-all duration-350 ${
              holdProgress > 0 ? 'border-neon-green bg-neon-green/20 scale-95 shadow-[0_0_15px_rgba(0,230,118,0.4)]' : 'border-neon-green/20'
            }`}
          >
            <Coins size={32} className={holdProgress > 0 ? 'animate-spin' : 'animate-pulse'} />
          </div>
          
          <h2 className="font-display font-black text-white text-2xl tracking-tight leading-none pt-1">
            EarnHub <span className="text-neon-green">Pro</span>
          </h2>
          
          {adminAccessEnabled ? (
            <span className="inline-block text-[10px] uppercase font-mono tracking-widest text-red-400 bg-red-500/10 border border-red-500/20 px-2.5 py-0.5 rounded-md">
              🛡️ Super Admin Access Enabled
            </span>
          ) : (
            <p className="text-xs text-gray-400 transition-opacity group-hover:opacity-80">
              {holdProgress > 0 ? `সহায়তার জন্য ধরে রাখুন... (${Math.ceil((4000 - holdProgress * 40) / 1000)}s)` : 'রিয়েল-টাইম আর্নিং প্লাটফর্ম। সম্পূর্ণ ফ্রিতে সহজ কাজ করে আয় করুন।'}
            </p>
          )}
        </div>

        {/* Mode switcher tabs (Fluid Switch logic) */}
        <div className="grid grid-cols-2 bg-gray-950 p-1.5 rounded-xl border border-gray-900">
          <button
            type="button"
            id="auth-toggle-login"
            onClick={() => { setMode('login'); setErrorMsg(''); }}
            className={`py-2 rounded-lg text-xs font-bold font-sans transition-all duration-200 cursor-pointer ${
              mode === 'login' 
                ? 'bg-[#1c2226] text-neon-green shadow-md border border-gray-800' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            লগইন (Login)
          </button>
          <button
            type="button"
            id="auth-toggle-register"
            onClick={() => { setMode('register'); setErrorMsg(''); }}
            className={`py-2 rounded-lg text-xs font-bold font-sans transition-all duration-200 cursor-pointer ${
              mode === 'register' 
                ? 'bg-[#1c2226] text-neon-green shadow-md border border-gray-800' 
                : 'text-gray-400 hover:text-white'
            }`}
          >
            রেজিস্ট্রেশন (Register)
          </button>
        </div>

        {errorMsg && (
          <div className="p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs text-center font-semibold">
            {errorMsg}
          </div>
        )}

        {/* Dynamic Signup/Login onboarding Form */}
        <form onSubmit={handleSubmit} className="space-y-4">
          
          <AnimatePresence mode="wait">
            <motion.div
              key={mode}
              initial={{ opacity: 0, x: mode === 'register' ? 20 : -20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: mode === 'register' ? -20 : 20 }}
              transition={{ duration: 0.15 }}
              className="space-y-4 text-left"
            >
              {mode === 'register' && (
                <>
                  {/* Full Name */}
                  <div>
                    <label htmlFor="user-fullname-field" className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1.5 font-mono">
                      পুরো নাম (Full Name)
                    </label>
                    <div className="relative">
                      <User className="absolute left-3.5 top-3.5 text-gray-500" size={16} />
                      <input
                        id="user-fullname-field"
                        type="text"
                        placeholder="উদাহরন: সাইদুল হাসান"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full bg-gray-950/60 border border-gray-800 rounded-xl pl-10 pr-4 py-3.5 text-xs text-white focus:outline-none focus:border-neon-green transition font-sans"
                        required
                      />
                    </div>
                  </div>

                  {/* Phone Number */}
                  <div>
                    <label htmlFor="user-phone-field" className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1.5 font-mono">
                      মোবাইল নাম্বার (Mobile Number)
                    </label>
                    <div className="relative">
                      <Smartphone className="absolute left-3.5 top-3.5 text-gray-500" size={16} />
                      <input
                        id="user-phone-field"
                        type="tel"
                        placeholder="উদাহরন: ০১৭XXXXXXXX"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full bg-gray-950/60 border border-gray-800 rounded-xl pl-10 pr-4 py-3.5 text-xs text-white focus:outline-none focus:border-neon-green transition font-mono"
                        required
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Email (Always active) */}
              <div>
                <label htmlFor="user-email-field" className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1.5 font-mono">
                  আপনার ইমেইল এড্রেস
                </label>
                <div className="relative">
                  <Mail className="absolute left-3.5 top-3.5 text-gray-500" size={16} />
                  <input
                    id="user-email-field"
                    type="email"
                    placeholder="উদাহরন: earner@test.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full bg-gray-950/60 border border-gray-800 rounded-xl pl-10 pr-4 py-3.5 text-xs text-white focus:outline-none focus:border-neon-green transition font-mono"
                    required
                  />
                </div>
              </div>

              {/* Password (Always active) */}
              <div>
                <label htmlFor="user-password-field" className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1.5 font-mono">
                  পাসওয়ার্ড (Password)
                </label>
                <div className="relative">
                  <Lock className="absolute left-3.5 top-3.5 text-gray-500" size={16} />
                  <input
                    id="user-password-field"
                    type="password"
                    placeholder="৬+ সংখ্যার পাসওয়ার্ড"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="w-full bg-gray-950/60 border border-gray-800 rounded-xl pl-10 pr-4 py-3.5 text-xs text-white focus:outline-none focus:border-neon-green transition font-mono"
                    required
                  />
                </div>
              </div>

              {mode === 'register' && (
                <>
                  {/* Confirm Password */}
                  <div>
                    <label htmlFor="user-confirm-password-field" className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1.5 font-mono">
                      কনফার্ম পাসওয়ার্ড (Confirm Password)
                    </label>
                    <div className="relative">
                      <Lock className="absolute left-3.5 top-3.5 text-gray-500" size={16} />
                      <input
                        id="user-confirm-password-field"
                        type="password"
                        placeholder="পাসওয়ার্ডটি পুনরায় লিখুন"
                        value={confirmPassword}
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="w-full bg-gray-950/60 border border-gray-800 rounded-xl pl-10 pr-4 py-3.5 text-xs text-white focus:outline-none focus:border-neon-green transition font-mono"
                        required
                      />
                    </div>
                  </div>

                  {/* Referral Code (Register only) */}
                  <div>
                    <label htmlFor="ref-code-field" className="text-[10px] text-gray-400 uppercase tracking-widest block mb-1.5 font-mono">
                      রেফার কোড (যদি থাকে - ১ টাকা ডিরেক্ট বোনাস)
                    </label>
                    <div className="relative">
                      <Users className="absolute left-3.5 top-3.5 text-gray-500" size={16} />
                      <input
                        id="ref-code-field"
                        type="text"
                        placeholder="উদাহরন: EHP-XXXXX"
                        value={referralCodeEntered}
                        onChange={(e) => setReferralCodeEntered(e.target.value)}
                        className="w-full bg-gray-950/60 border border-gray-800 rounded-xl pl-10 pr-4 py-3.5 text-xs text-white focus:outline-none focus:border-neon-green transition font-mono uppercase"
                      />
                    </div>
                  </div>
                </>
              )}
            </motion.div>
          </AnimatePresence>

          <button
            id="auth-signup-btn"
            type="submit"
            disabled={loading}
            className="w-full py-4 mt-2 rounded-xl bg-neon-green text-black font-extrabold font-display text-sm flex items-center justify-center gap-2 hover:brightness-105 active:brightness-95 transition cursor-pointer shadow-[0_0_15px_rgba(0,230,118,0.2)]"
          >
            {loading ? 'দয়া করে অপেক্ষা করুন...' : mode === 'register' ? 'একাউন্ট রেজিস্ট্রার করুন' : 'লগইন করুন'}
            <ArrowRight size={16} />
          </button>

          {/* Premium WhatsApp Support Integration for immediate support assistance */}
          <a
            id="whatsapp-direct-support-btn"
            href="https://wa.me/8801302517769"
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 py-3 px-4 text-xs font-bold text-[#25D366] hover:text-[#1ebd59] bg-[#25D366]/10 border border-[#25D366]/20 hover:border-[#25D366]/30 rounded-xl transition-all duration-200 text-center cursor-pointer"
          >
            <MessageCircle size={15} className="shrink-0" />
            <span>যেকোনো সমস্যায় হোয়াটসঅ্যাপ সাপোর্ট: ০১৩০২৫১৭৭৬৯</span>
          </a>

        </form>

        {/* Admin or standard fast presets buttons */}
        <div className="border-t border-gray-905 pt-5 text-center space-y-3.5">
          <span className="text-[10px] uppercase tracking-wider text-gray-500 font-mono block">
            দ্রুত টেস্টিং করার একাউন্টস
          </span>
          
          <div className="grid grid-cols-1 gap-2 text-xs">
            {/* Standard Tester */}
            <button
              id="preset-user-login-btn"
              onClick={() => handleQuickPreset('earner@test.com')}
              className="p-3.5 rounded-xl bg-gray-950 border border-gray-900 hover:border-gray-800 text-gray-300 text-left flex items-center justify-between cursor-pointer transition-all w-full"
            >
              <div className="flex items-center gap-2.5">
                <UserCheck size={16} className="text-neon-green shrink-0" />
                <div>
                  <span className="font-bold block text-white">Earn Profile</span>
                  <span className="text-[10px] text-gray-500">earner@test.com</span>
                </div>
              </div>
              <ArrowRight size={14} className="text-gray-600" />
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
