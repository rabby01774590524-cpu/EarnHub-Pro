import { useState, useEffect } from 'react';
import { Share2, Copy, Check, Users, Gift, HelpCircle, Trophy } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppUser, ReferralRecord } from '../types';
import { databaseService } from '../services/db';

interface ReferralViewProps {
  user: AppUser;
}

export default function ReferralView({ user }: ReferralViewProps) {
  const [copiedCode, setCopiedCode] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [referrals, setReferrals] = useState<ReferralRecord[]>([]);
  const [loading, setLoading] = useState(true);

  // Hardcoded or dynamically formulated link based on environment (e.g. App URL)
  const appReferralLink = `${window.location.origin}/ref/${user.referralCode}`;

  useEffect(() => {
    fetchReferrals();
  }, [user.uid]);

  const fetchReferrals = async () => {
    setLoading(true);
    try {
      const records = await databaseService.getReferralsByUser(user.uid);
      setReferrals(records);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, type: 'code' | 'link') => {
    navigator.clipboard.writeText(text);
    if (type === 'code') {
      setCopiedCode(true);
      setTimeout(() => setCopiedCode(false), 2000);
    } else {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2000);
    }
  };

  // Calculate total commission reward earned
  const totalReferralRewards = referrals.reduce((sum, r) => sum + (r.reward || 0), 0);

  return (
    <div className="space-y-6">
      {/* 1. Header Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-950/40 to-teal-950/40 border border-emerald-500/10 p-6 md:p-8">
        <div className="absolute top-0 right-0 w-32 h-32 bg-neon-green/10 rounded-full blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
          <div>
            <span className="text-neon-green text-[10px] uppercase font-mono tracking-widest bg-neon-green/10 border border-neon-green/20 px-2 py-1 rounded">
              ইনভাইট এন্ড আর্ন
            </span>
            <h2 className="text-2xl font-display font-bold text-white tracking-tight mt-3">
              আপনার বন্ধুদের রেফার করুন!
            </h2>
            <p className="text-xs text-gray-300 mt-1 max-w-md leading-relaxed">
              আপনার রেফার করা বন্ধু অ্যাপ থেকে টাকা উত্তোলন করলেই প্রতি উত্তোলনে তার ১০% কমিশন ইনস্ট্যান্ট আপনার আইডিতে যোগ হয়ে যাবে! 🎁
            </p>
          </div>
          
          <div className="flex gap-4 p-4 rounded-xl bg-gray-900/60 border border-gray-800 shrink-0">
            <div className="text-center">
              <span className="text-[10px] uppercase tracking-wider text-gray-400 font-mono">মোট ইনভাইট</span>
              <p className="text-2xl font-bold text-white font-mono">{referrals.length} জন</p>
            </div>
            <div className="w-px h-10 bg-gray-800" />
            <div className="text-center">
              <span className="text-[10px] uppercase tracking-wider text-gray-400 font-mono">রেফারাল কমিশন</span>
              <p className="text-2xl font-bold text-neon-green font-mono">৳{totalReferralRewards.toFixed(2)}</p>
            </div>
          </div>
        </div>
      </div>

      {/* 2. Share Panel options */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* Referral code share card */}
        <div className="bg-[#12161a] border border-gray-800 rounded-xl p-5 md:p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Trophy className="text-neon-green" size={18} />
            <span className="font-display font-bold text-white text-base">আপনার রেফার কোড</span>
          </div>
          <p className="text-xs text-gray-400">
            আপনার এই রেফার কোডটি বন্ধুদের রেজিস্ট্রেশন এর সময় ব্যবহার করতে বলুন।
          </p>

          <div className="flex items-center justify-between gap-3 bg-gray-950 hover:bg-gray-950/80 p-3.5 rounded-xl border border-gray-900 transition-all font-mono">
            <span className="font-bold text-lg text-white tracking-widest select-all uppercase">
              {user.referralCode}
            </span>
            <button
              id="copy-ref-code-btn"
              onClick={() => copyToClipboard(user.referralCode, 'code')}
              className="p-2 rounded-lg bg-neon-green/10 text-neon-green hover:bg-neon-green/20 transition-all cursor-pointer"
            >
              {copiedCode ? <Check size={16} /> : <Copy size={16} />}
            </button>
          </div>
          <p className="text-[10px] text-gray-500 font-mono">
            {copiedCode ? 'রেফার কোড কপি করা হয়েছে!' : 'কপি বাটনে ক্লিক করে কোড কপি করুন।'}
          </p>
        </div>

        {/* Copy full Referral register link */}
        <div className="bg-[#12161a] border border-gray-800 rounded-xl p-5 md:p-6 space-y-4">
          <div className="flex items-center gap-2">
            <Share2 className="text-teal-400" size={18} />
            <span className="font-display font-bold text-white text-base">রেফারেল লিংক শেয়ার</span>
          </div>
          <p className="text-xs text-gray-400">
            এই লিংকের মাধ্যমে যুক্ত হলে সরাসরি পেয়ে যাবেন স্পেশাল ক্রেডিট বোনাস।
          </p>

          <div className="flex items-center justify-between gap-3 bg-gray-950 hover:bg-gray-950/80 p-3.5 rounded-xl border border-gray-900 transition-all font-mono">
            <span className="text-xs text-gray-400 truncate max-w-[200px] select-all">
              {appReferralLink}
            </span>
            <button
              id="copy-ref-link-btn"
              onClick={() => copyToClipboard(appReferralLink, 'link')}
              className="p-2 rounded-lg bg-teal-400/10 text-teal-400 hover:bg-teal-400/20 transition-all cursor-pointer"
            >
              {copiedLink ? <Check size={16} /> : <Copy size={16} />}
            </button>
          </div>
          <p className="text-[10px] text-gray-500 font-mono">
            {copiedLink ? 'লিংক কপি করা হয়েছে!' : 'এই ইউনিক লিঙ্কটি পাঠিয়ে বন্ধুদের ইনভাইট করুন।'}
          </p>
        </div>

      </div>

      {/* 3. Steps Guide */}
      <div className="bg-[#12161a] border border-gray-800 rounded-xl p-5">
        <h4 className="font-bold text-white text-sm mb-3.5 flex items-center gap-2">
          <HelpCircle size={16} className="text-neon-green" /> কিভাবে ফ্রিতে রেফার করবেন?
        </h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs text-gray-400">
          <div className="p-3 bg-gray-950 rounded-lg">
            <span className="font-bold text-neon-green">ধাপ ১:</span> <br />
            আপনার ইউনিক রেফার লিঙ্ক বা কোডটি আপনার বন্ধুদের সাথে শেয়ার করুন।
          </div>
          <div className="p-3 bg-gray-950 rounded-lg">
            <span className="font-bold text-neon-green">ধাপ ২:</span> <br />
            লিঙ্ক বা কোড ব্যবহার করে তারা প্লাটফর্মে নতুন একাউন্ট রেজিস্ট্রার করবে।
          </div>
          <div className="p-3 bg-gray-950 rounded-lg">
            <span className="font-bold text-neon-green">ধাপ ৩:</span> <br />
            আপনার রেফার করা বন্ধু যখনই অ্যাপ থেকে টাকা উত্তোলন (Withdraw) করবে, অ্যাডমিন কর্তৃক সেই উইথড্র কনফার্ম বা অ্যাপ্রুভ হওয়ার সাথে সাথেই তার উত্তোলিত টাকার ১০% কমিশন ইনস্ট্যান্ট আপনার আইডিতে যোগ হয়ে যাবে!
          </div>
        </div>
      </div>

      {/* 4. Real-time active referrals invited */}
      <div>
        <div className="flex items-center gap-2 mb-4">
          <div className="w-1.5 h-6 bg-neon-green rounded-full" />
          <h3 className="font-display text-lg font-bold text-white">আপনার আমন্ত্রিত ফ্রেন্ডলিস্ট</h3>
        </div>

        {loading ? (
          <div className="text-center py-6 text-gray-500 text-xs">রেফারলিস্ট লোড হচ্ছে...</div>
        ) : referrals.length === 0 ? (
          <div className="bg-[#12161a] border border-gray-850 p-8 rounded-xl text-center text-gray-500 text-xs text-semibold">
            <Users size={28} className="mx-auto mb-2 text-gray-600 block" />
            এখনো কেউ আপনার রেফারে জয়েন করেনি। শেয়ার করে পেমেন্ট আয় করা শুরু করুন!
          </div>
        ) : (
          <div className="overflow-x-auto rounded-xl border border-gray-800 bg-[#12161a]">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-900/60 border-b border-gray-800 text-xs text-gray-400 font-mono">
                  <th className="p-3.5">আমন্ত্রিত ফ্রেন্ড ইমেইল</th>
                  <th className="p-3.5">বোনাস রিওয়ার্ড</th>
                  <th className="p-3.5 text-right">তারিখ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-900 text-xs">
                {referrals.map((rec) => (
                  <tr key={rec.id} className="hover:bg-gray-950/20">
                    <td className="p-3.5 font-bold text-white">{rec.refereeEmail}</td>
                    <td className="p-3.5 text-neon-green font-mono font-bold">+৳{rec.reward.toFixed(2)}</td>
                    <td className="p-3.5 text-gray-400 font-mono text-right">{new Date(rec.createdAt).toLocaleDateString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
