import React, { useState, useEffect } from 'react';
import { CreditCard, ArrowUpRight, Clock, ShieldAlert, CheckCircle2, History, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { AppUser, WithdrawalRequest, GatewayConfig } from '../types';
import { databaseService } from '../services/db';

interface WithdrawViewProps {
  user: AppUser;
  onRefreshUser: () => void;
}

export default function WithdrawView({ user, onRefreshUser }: WithdrawViewProps) {
  const [amount, setAmount] = useState<number>(200);
  const [method, setMethod] = useState<'bKash' | 'Nagad' | 'Rocket' | 'Binance'>('bKash');
  const [accountNumber, setAccountNumber] = useState<string>('');
  const [withdrawing, setWithdrawing] = useState(false);
  const [withdrawals, setWithdrawals] = useState<WithdrawalRequest[]>([]);
  const [gateways, setGateways] = useState<GatewayConfig[]>([]);
  
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  useEffect(() => {
    fetchWithdrawals();
    fetchGateways();
  }, [user.uid]);

  const fetchWithdrawals = async () => {
    try {
      const allWiths = await databaseService.getWithdrawals();
      const filtered = allWiths.filter(w => w.userId === user.uid);
      setWithdrawals(filtered);
    } catch (err) {
      console.error(err);
    }
  };

  const fetchGateways = async () => {
    try {
      const list = await databaseService.getGateways();
      setGateways(list);
      // Try to find a non-sold-out gateway to select by default
      const activeGate = list.find(g => !g.soldOut) || list[0];
      if (activeGate) {
        setMethod(activeGate.id);
        setAmount(activeGate.min);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleWithdrawalRequestSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    const activeGate = gateways.find(g => g.id === method) || { min: 200, max: 20000, soldOut: false };

    if (activeGate.soldOut) {
      setErrorMsg('দুঃখিত, এই পেমেন্ট মেথডটি বর্তমানে সোল্ড আউট রয়েছে। ❌');
      return;
    }

    // Verification gates
    if (amount < activeGate.min) {
      setErrorMsg(`দুঃখিত, সর্বনিম্ন উইথড্রয়াল লিমিট ৳${activeGate.min} টাকা!`);
      return;
    }
    if (amount > activeGate.max) {
      setErrorMsg(`দুঃখিত, সর্বোচ্চ উইথড্রয়াল লিমিট ৳${activeGate.max} টাকা!`);
      return;
    }
    if (user.balance < amount) {
      setErrorMsg(`আপনার একাউন্টে পর্যাপ্ত ব্যালেন্স নেই। বর্তমান ব্যালেন্স: ৳${user.balance.toFixed(2)}`);
      return;
    }

    // Input validation checks based on method selection
    if (method === 'Binance') {
      const binanceRegex = /^\d{9}$/;
      if (!binanceRegex.test(accountNumber.trim())) {
        setErrorMsg('দয়া করে একটি সঠিক ৯ ডিজিটের বাইনান্স পে আইডি প্রদান করুন!');
        return;
      }
    } else {
      // BD Account number validator
      const bdPhoneRegex = /^(?:\+?88)?01[3-9]\d{8}$/;
      if (!bdPhoneRegex.test(accountNumber)) {
        setErrorMsg('দয়া করে একটি সঠিক ১১ ডিজিটের বাংলাদেশী মোবাইল নম্বর প্রদান করুন!');
        return;
      }
    }

    setWithdrawing(true);
    try {
      await databaseService.requestWithdrawal(user.uid, user.email, amount, method, accountNumber);
      setSuccessMsg(`আপনার ৳${amount.toFixed(2)} টাকা উত্তোলনের অনুরোধটি সফলভাবে পাঠানো হয়েছে!`);
      setAccountNumber('');
      setAmount(activeGate.min);
      onRefreshUser();
      await fetchWithdrawals();
    } catch (err: any) {
      setErrorMsg(err.message || 'উইথড্রয়াল প্রসেসিং ব্যর্থ হয়েছে, আবার চেষ্টা করুন।');
    } finally {
      setWithdrawing(false);
    }
  };

  const getActiveGate = () => {
    return gateways.find(g => g.id === method) || { min: 200, max: 20000, soldOut: false };
  };

  const isSelectedGateSoldOut = getActiveGate().soldOut;

  return (
    <div className="space-y-6">
      {/* Dynamic Status Notifications */}
      <AnimatePresence>
        {successMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 rounded-xl bg-neon-green/10 border border-neon-green/30 text-neon-green flex items-center gap-3 text-sm font-semibold shadow-md"
          >
            <CheckCircle2 size={18} className="shrink-0" />
            <span>{successMsg}</span>
          </motion.div>
        )}
        {errorMsg && (
          <motion.div
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center gap-3 text-sm font-semibold shadow-md"
          >
            <ShieldAlert size={18} className="shrink-0" />
            <span>{errorMsg}</span>
          </motion.div>
        )}
      </AnimatePresence>

      <div className="flex flex-col lg:flex-row gap-6">
        
        {/* 1. Request Payout form */}
        <div className="flex-1 bg-[#12161a] border border-gray-800 rounded-xl p-5 md:p-6">
          <div className="flex items-center gap-2 mb-5">
            <div className="p-1.5 rounded-lg bg-neon-green/10 text-neon-green">
              <CreditCard size={18} />
            </div>
            <h3 className="font-display text-lg font-bold text-white">বাংলাদেশী পেমেন্ট উইথড্রয়াল</h3>
          </div>

          <form onSubmit={handleWithdrawalRequestSubmit} className="space-y-4">
            
            {/* Payment gateway selector */}
            <div>
              <label className="text-xs text-gray-400 font-mono uppercase tracking-widest block mb-2">
                পেমেন্ট মেথড সিলেক্ট করুন
              </label>
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
                {[
                  { 
                    key: 'bKash', 
                    label: 'বিকাশ (bKash)', 
                    icon: (
                      <div className="w-10 h-10 rounded-xl bg-[#e2125f]/10 border border-[#e2125f]/20 flex items-center justify-center shrink-0">
                        <svg viewBox="0 0 100 100" className="w-7 h-7" xmlns="http://www.w3.org/2000/svg">
                          <rect width="100" height="100" rx="22" fill="#E2125F" />
                          <path d="M22 64 L38 31 L54 54 L76 24 L65 72 L44 54 Z" fill="#FFFFFF" />
                          <circle cx="34" cy="38" r="4.5" fill="#E2125F" />
                        </svg>
                      </div>
                    )
                  },
                  { 
                    key: 'Nagad', 
                    label: 'নগদ (Nagad)', 
                    icon: (
                      <div className="w-10 h-10 rounded-xl bg-[#ea4c21]/10 border border-[#ea4c21]/20 flex items-center justify-center shrink-0">
                        <svg viewBox="0 0 100 100" className="w-7 h-7" xmlns="http://www.w3.org/2000/svg">
                          <rect width="100" height="100" rx="22" fill="#EA4C21" />
                          <circle cx="50" cy="50" r="22" stroke="#FFFFFF" strokeWidth="6" fill="none" />
                          <path d="M50 20 A30 30 0 0 1 80 50" stroke="#FFFFFF" strokeWidth="8" strokeLinecap="round" fill="none" />
                          <circle cx="50" cy="50" r="8" fill="#FFFFFF" />
                        </svg>
                      </div>
                    )
                  },
                  { 
                    key: 'Rocket', 
                    label: 'রকেট (Rocket)', 
                    icon: (
                      <div className="w-10 h-10 rounded-xl bg-[#92278f]/10 border border-[#92278f]/20 flex items-center justify-center shrink-0">
                        <svg viewBox="0 0 100 100" className="w-7 h-7" xmlns="http://www.w3.org/2000/svg">
                          <rect width="100" height="100" rx="22" fill="#8C3494" />
                          <path d="M50 20 C60 34 60 54 55 68 L45 68 C40 54 40 34 50 20 Z" fill="#FFFFFF" />
                          <path d="M50 68 L45 77 L55 77 Z" fill="#F15A22" />
                          <path d="M36 58 C41 58 45 61 45 66 L39 70 Z" fill="#FFFFFF" />
                          <path d="M64 58 C59 58 55 61 55 66 L61 70 Z" fill="#FFFFFF" />
                        </svg>
                      </div>
                    )
                  },
                  { 
                    key: 'Binance', 
                    label: 'Binance (Pay ID)', 
                    icon: (
                      <div className="w-10 h-10 rounded-xl bg-[#f0b90b]/10 border border-[#f0b90b]/20 flex items-center justify-center shrink-0">
                        <svg viewBox="0 0 120 120" className="w-7 h-7" xmlns="http://www.w3.org/2000/svg">
                          <rect width="120" height="120" rx="26" fill="#12161A" stroke="#F0B90B" strokeWidth="2.5" />
                          <path d="M60 22 L75 37 L60 52 L45 37 Z" fill="#F0B90B" />
                          <path d="M60 68 L75 83 L60 98 L45 83 Z" fill="#F0B90B" />
                          <path d="M37 45 L52 60 L37 75 L22 60 Z" fill="#F0B90B" />
                          <path d="M83 45 L98 60 L83 75 L68 60 Z" fill="#F0B90B" />
                          <path d="M60 45 L69 54 L60 63 L51 54 Z" fill="#F0B90B" />
                        </svg>
                      </div>
                    )
                  }
                ].map((gate) => {
                  const gateConfig = gateways.find(g => g.id === gate.key) || { min: 200, max: 20000, soldOut: false };
                  return (
                    <button
                      key={gate.key}
                      type="button"
                      onClick={() => !gateConfig.soldOut && setMethod(gate.key as any)}
                      disabled={gateConfig.soldOut}
                      className={`p-4 rounded-xl border text-center transition flex flex-col items-center justify-center gap-2.5 ${
                        gateConfig.soldOut
                          ? 'border-gray-900 bg-gray-950/20 opacity-50 cursor-not-allowed'
                          : method === gate.key 
                          ? 'border-neon-green bg-gradient-to-b from-[#1b2229] to-[#0d1013] shadow-md cursor-pointer' 
                          : 'border-gray-800 bg-gray-950/40 hover:bg-gray-950 cursor-pointer'
                      }`}
                    >
                      {gate.icon}
                      <span className="text-xs font-bold text-white leading-tight">{gate.label}</span>
                      
                      {gateConfig.soldOut ? (
                        <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-gray-800 text-gray-500 border border-gray-700 font-sans tracking-wide">
                          সোল্ড আউট (Sold Out)
                        </span>
                      ) : (
                        <span className={`w-3.5 h-3.5 rounded-full flex items-center justify-center border ${
                          method === gate.key ? 'border-neon-green text-neon-green' : 'border-gray-700'
                        }`}>
                          {method === gate.key && <span className="w-1.5 h-1.5 bg-neon-green rounded-full" />}
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Wallet Cash Number */}
            <div>
              <label htmlFor="account-num" className="text-xs text-gray-400 font-mono uppercase tracking-widest block mb-2">
                {method === 'Binance'
                  ? 'বাইনান্স পে আইডি (Pay ID)'
                  : `ব্যক্তিগত ${method === 'bKash' ? 'বিকাশ' : method === 'Nagad' ? 'নগদ' : 'রকেট'} অ্যাকাউন্ট নম্বর (১১ ডিজিট)`}
              </label>
              <input
                id="account-num"
                type="text"
                placeholder={method === 'Binance' ? 'Eg. 398456123' : 'Eg. 01712345678'}
                value={accountNumber}
                onChange={(e) => setAccountNumber(e.target.value)}
                className="w-full bg-gray-950/60 border border-gray-800 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-neon-green transition-all font-mono"
                required
                disabled={isSelectedGateSoldOut}
              />
            </div>

            {/* Cash Out Amount */}
            <div>
              <div className="flex justify-between text-xs text-gray-400 font-mono uppercase tracking-widest mb-2">
                <span>উত্তোলনের পরিমাণ (টাকা)</span>
                <span>সীমা: ৳{getActiveGate().min} - ৳{getActiveGate().max.toLocaleString()}</span>
              </div>
              <div className="relative">
                <span className="absolute left-4 top-3.5 text-neon-green font-bold font-mono">৳</span>
                <input
                  id="withdraw-amount-picker"
                  type="number"
                  min={getActiveGate().min}
                  max={getActiveGate().max}
                  step="5"
                  value={amount}
                  onChange={(e) => setAmount(Number(e.target.value))}
                  className="w-full bg-gray-950/60 border border-gray-800 rounded-xl pl-8 pr-4 py-3 text-sm text-white font-bold focus:outline-none focus:border-neon-green transition-all font-mono"
                  required
                  disabled={isSelectedGateSoldOut}
                />
              </div>
              <div className="flex gap-2 mt-2.5">
                {[200, 500, 1000, 2000].map((val) => (
                  <button
                    key={val}
                    type="button"
                    onClick={() => setAmount(val)}
                    disabled={isSelectedGateSoldOut}
                    className="text-[10px] font-bold font-mono px-2.5 py-1.5 rounded-lg border border-gray-800 hover:border-neon-green/35 text-gray-400 bg-gray-950 hover:bg-gray-900 cursor-pointer transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    +৳{val}
                  </button>
                ))}
              </div>
            </div>

            {/* Quick Summary Cash rules */}
            <div className="p-3.5 rounded-xl bg-gray-950 text-xs text-gray-400 space-y-1.5 border border-gray-900">
              <div className="flex justify-between">
                <span>সার্ভিস ফি (ভ্যাট সহ ০.০০%):</span>
                <span className="font-mono text-gray-300">৳০.০০</span>
              </div>
              <div className="flex justify-between text-white font-bold">
                <span>উত্তোলন করার পর ব্যালেন্স থাকবে:</span>
                <span className="font-mono text-neon-green">৳{Math.max(0, user.balance - amount).toFixed(2)}</span>
              </div>
            </div>

            <button
              id="request-payout-btn"
              type="submit"
              disabled={withdrawing || user.balance < amount || isSelectedGateSoldOut}
              className={`w-full py-3.5 rounded-xl text-black font-bold font-display text-sm tracking-wide transition flex items-center justify-center gap-2 ${
                user.balance >= amount && !withdrawing && !isSelectedGateSoldOut
                  ? 'bg-neon-green hover:neon-btn-glow cursor-pointer'
                  : 'bg-gray-800 text-gray-500 cursor-not-allowed'
              }`}
            >
              {withdrawing ? 'প্রসেসিং হচ্ছে...' : isSelectedGateSoldOut ? 'এই গেটওয়ে সোল্ড আউট রয়েছে' : `${method} রিকোয়েস্ট পাঠান`}
            </button>
          </form>
        </div>

        {/* Payout Limits and notes */}
        <div className="w-full lg:w-80 space-y-4 shrink-0">
          <div className="bg-[#12161a] border border-gray-800 rounded-xl p-5 text-xs text-gray-400 space-y-3">
            <span className="font-bold text-white text-sm block mb-1">পেমেন্ট পেমেন্ট পলিসি:</span>
            <p className="leading-relaxed">
              ১. উইথড্রয়াল প্রসেসিং হতে সর্বোচ্চ <span className="text-white font-semibold">২৪ ঘণ্টা</span> সময় লাগবে।
            </p>
            <p className="leading-relaxed">
              ২. বিকাশ নম্বর, নগদ নম্বর ও রকেট নম্বর পার্সোনাল হতে হবে (এজেন্ট নম্বরে পেমেন্ট পাঠানো হবে না)।
            </p>
            <p className="leading-relaxed">
              ৩. ভুল অ্যাকাউন্ট নম্বর প্রদান করলে, এডমিন কোনোভাবেই রিফান্ড দিতে বাধ্য থাকবে না। তাই সঠিক নম্বর দিন।
            </p>
          </div>

          <div className="bg-emerald-500/5 border border-emerald-500/10 p-5 rounded-xl flex items-start gap-2.5">
            <Clock className="text-emerald-400 mt-0.5 shrink-0" size={16} />
            <div>
              <span className="font-bold text-emerald-300 text-[11px] uppercase tracking-wider block font-mono">লাইভ উইথড্র সময়সূচী</span>
              <p className="text-xs text-gray-300 mt-1">
                সপ্তাহে ৭ দিন ২৪ ঘন্টাই আমাদের পেমেন্ট রিসিভিং গেটওয়ে খোলা রয়েছে। ইনস্ট্যান্ট প্রসেস করা হয়ে থাকে।
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* 4. Active user withdrawal queue requests in real-time */}
      {withdrawals.length > 0 && (
        <div className="mt-8">
          <div className="flex items-center gap-2 mb-4">
            <div className="p-1 rounded bg-[#1e2330]">
              <History size={16} className="text-neon-green" />
            </div>
            <h3 className="font-display text-lg font-bold text-white">আপনার পেমেন্ট উইথড্র হিস্টোরি</h3>
          </div>

          <div className="overflow-x-auto rounded-xl border border-gray-800 bg-[#12161a]">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-gray-900/60 border-b border-gray-800 text-xs text-gray-400 font-mono">
                  <th className="p-3.5">উইথড্রয়াল আইডি</th>
                  <th className="p-3.5">পরিমাণ</th>
                  <th className="p-3.5">মেথড / অ্যাকাউন্ট নম্বর</th>
                  <th className="p-3.5">তারিখ</th>
                  <th className="p-3.5 text-right">স্ট্যাটাস</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-900 text-xs">
                {withdrawals.map((req) => (
                  <tr key={req.id} className="hover:bg-gray-950/20">
                    <td className="p-3.5 text-gray-400 font-mono truncate max-w-[120px]">{req.id}</td>
                    <td className="p-3.5 font-mono text-neon-green font-bold">৳{req.amount.toFixed(2)}</td>
                    <td className="p-3.5">
                      <span className="font-bold text-white uppercase text-[10px] bg-gray-900 border border-gray-800 px-2 py-0.5 rounded mr-2">
                        {req.paymentMethod}
                      </span>
                      <span className="font-mono text-gray-300">{req.accountNumber}</span>
                    </td>
                    <td className="p-3.5 text-gray-400 font-mono">{new Date(req.createdAt).toLocaleDateString()}</td>
                    <td className="p-3.5 text-right">
                      <span className={`px-2.5 py-1 rounded text-[10px] font-bold tracking-wide uppercase ${
                        req.status === 'Pending' 
                          ? 'bg-amber-400/10 text-amber-400' 
                          : req.status === 'Approved' 
                          ? 'bg-neon-green/10 text-neon-green' 
                          : 'bg-red-500/10 text-red-400'
                      }`}>
                        {req.status === 'Pending' ? 'পেন্ডিং' : req.status === 'Approved' ? 'সফল পেমেন্ট' : 'বাতিল করা হয়েছে'}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
