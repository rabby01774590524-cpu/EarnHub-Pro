import { useEffect, useState } from 'react';
import { X, Send, Bell, Calendar, Award, Flame, Wallet, Clock } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface WelcomeModalProps {
  onClose?: () => void;
}

export default function WelcomeModal({ onClose }: WelcomeModalProps) {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Show only once per active browser session
    const hasSeen = sessionStorage.getItem('earnhub_welcome_seen');
    if (!hasSeen) {
      setIsOpen(true);
    }
  }, []);

  const handleClose = () => {
    sessionStorage.setItem('earnhub_welcome_seen', 'true');
    setIsOpen(false);
    if (onClose) onClose();
  };

  const telegramLink = 'https://t.me/EarnHubPro1';

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          {/* Backdrop Blur */}
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-black/75 backdrop-blur-md"
            onClick={handleClose}
          />

          {/* Modal Container */}
          <motion.div 
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            transition={{ type: 'spring', damping: 25, stiffness: 350 }}
            className="relative w-full max-w-lg overflow-hidden rounded-2xl bg-[#12161a] border border-neon-green/30 shadow-[0_0_50px_rgba(0,230,118,0.15)] text-gray-100 z-10"
          >
            {/* Header Aesthetic Accent */}
            <div className="h-1.5 w-full bg-gradient-to-r from-emerald-500 via-neon-green to-teal-400" />
            
            <button 
              id="close-welcome-modal"
              onClick={handleClose}
              className="absolute top-4 right-4 text-gray-400 hover:text-white p-1.5 rounded-full hover:bg-gray-800 transition-colors"
            >
              <X size={20} />
            </button>

            {/* Content Container */}
            <div className="p-6 md:p-8">
              <div className="flex items-center gap-3 mb-6">
                <div className="p-2.5 rounded-xl bg-neon-green/10 text-neon-green border border-neon-green/20 animate-pulse">
                  <Bell size={24} />
                </div>
                <div>
                  <h3 className="font-display text-xl font-bold tracking-tight text-white">
                    EarnHub Pro Notification
                  </h3>
                  <p className="text-xs text-neon-green">ঘোষনা এবং সাইট নির্দেশিকা</p>
                </div>
              </div>

              {/* Information Cards Grid */}
              <div className="space-y-3 mb-8">
                <div className="flex items-center gap-4 p-3.5 rounded-xl bg-gray-900/60 border border-gray-800 hover:border-neon-green/20 transition-all">
                  <Calendar className="text-emerald-400 shrink-0" size={20} />
                  <div>
                    <p className="text-[11px] text-gray-400 uppercase tracking-widest font-mono">লঞ্চিং ডেট</p>
                    <p className="font-semibold text-white">২৬-০৫-২০২৬</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-xl bg-gray-900/60 border border-gray-800 hover:border-neon-green/20 transition-all">
                    <Award className="text-neon-green shrink-0 mb-1" size={18} />
                    <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">সাইন-আপ বোনাস</p>
                    <p className="font-bold text-white text-base">৳১.০০ টাকা</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-gray-900/60 border border-gray-800 hover:border-neon-green/20 transition-all">
                    <Flame className="text-amber-400 shrink-0 mb-1" size={18} />
                    <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">প্রতিদিন চেকিং</p>
                    <p className="font-bold text-white text-base">৳০.৫০ - ৳৫.০০</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div className="p-3.5 rounded-xl bg-gray-900/60 border border-gray-800 hover:border-neon-green/20 transition-all">
                    <Wallet className="text-cyan-400 shrink-0 mb-1" size={18} />
                    <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">সর্বনিম্ন উত্তোলন</p>
                    <p className="font-bold text-white text-base">৳২০০ টাকা</p>
                  </div>

                  <div className="p-3.5 rounded-xl bg-gray-900/60 border border-gray-800 hover:border-neon-green/20 transition-all">
                    <Clock className="text-purple-400 shrink-0 mb-1" size={18} />
                    <p className="text-[10px] text-gray-400 uppercase tracking-widest font-mono">উত্তোলনের সময়</p>
                    <p className="font-semibold text-white text-sm">২৪ ঘণ্টা খোলা</p>
                  </div>
                </div>

                <div className="p-3.5 rounded-xl bg-gray-900/60 border border-emerald-500/10 hover:border-neon-green/20 transition-all">
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-gray-400">স্পন্সর টাস্ক ইনকাম:</span>
                    <span className="font-mono text-neon-green font-bold">প্রতি এডে ৳০.১৫ টাকা</span>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-2.5">
                <a 
                  id="welcome-telegram-support"
                  href={telegramLink}
                  target="_blank"
                  rel="noreferrer referrer"
                  className="flex items-center justify-center gap-2 w-full py-3.5 px-4 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-500 text-white font-bold hover:brightness-110 active:brightness-95 shadow-[0_4px_20px_rgba(16,185,129,0.25)] hover:neon-btn-glow transition-all"
                >
                  <Send size={18} className="fill-white" />
                  টেলিগ্রাম সাপোর্ট গ্রুপ
                </a>

                <a 
                  id="welcome-telegram-channel"
                  href={telegramLink}
                  target="_blank"
                  rel="noreferrer referrer"
                  className="flex items-center justify-center gap-2 w-full py-3.5 px-4 rounded-xl bg-gray-900 border border-gray-800 hover:border-emerald-500/50 text-emerald-400 hover:text-emerald-300 font-bold hover:bg-[#1a2026] active:bg-gray-950 transition-all text-center"
                >
                  <Send size={18} className="text-emerald-400 shrink-0" />
                  টেলিগ্রাম অফিশিয়াল চ্যানেল
                </a>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
