/**
 * EarnHub Pro - Unified Database Service (Firestore + LocalStorage Hybrid Fallback)
 */

import { initializeApp, getApp, getApps } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged, User as FirebaseUser } from 'firebase/auth';
import { getFirestore, doc, getDoc, setDoc, updateDoc, collection, addDoc, getDocs, query, where, limit, getDocFromServer, onSnapshot } from 'firebase/firestore';
import { AppUser, EarnTask, TaskSubmission, WithdrawalRequest, ReferralRecord, GatewayConfig, AccountConfig, SubmittedAccount, SystemConfig } from '../types';
import firebaseConfig from '../../firebase-applet-config.json';

// Detect if we have real Firebase credentials
const isFirebaseReady = 
  firebaseConfig && 
  firebaseConfig.apiKey && 
  firebaseConfig.apiKey !== 'PLACEHOLDER_KEY';

let app: any = null;
let firestoreDb: any = null;
let firebaseAuth: any = null;

if (isFirebaseReady) {
  try {
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();
    firestoreDb = getFirestore(app, firebaseConfig.firestoreDatabaseId);
    firebaseAuth = getAuth(app);
    
    // Validate connection to Firestore
    const testConnection = async () => {
      try {
        await getDocFromServer(doc(firestoreDb, 'test', 'connection'));
      } catch (error) {
        if (error instanceof Error && error.message.includes('the client is offline')) {
          console.warn("Please check your Firebase configuration: Firestore client is offline.");
        }
      }
    };
    testConnection();
  } catch (err) {
    console.warn("Firebase initialization failed, falling back to local simulation:", err);
  }
}

// ------------------------------------
// LOCAL STORAGE SIMULATION BACKEND
// ------------------------------------
const LOCAL_DB_KEYS = {
  USERS: 'earnhub_users',
  TASKS: 'earnhub_tasks',
  SUBMISSIONS: 'earnhub_submissions',
  WITHDRAWALS: 'earnhub_withdrawals',
  REFERRALS: 'earnhub_referrals',
  CURRENT_USER_ID: 'earnhub_current_uid',
  GATEWAYS: 'earnhub_gateways',
  ACCOUNT_CONFIGS: 'earnhub_account_configs',
  SUBMITTED_ACCOUNTS: 'earnhub_submitted_accounts',
};

// Initial task static definition
const DEFAULT_TASKS: EarnTask[] = [
  {
    id: 'sponsor_ad_1',
    title: 'স্পন্সর টাস্ক (Watch Premium Ad Spot)',
    reward: 0.20,
    type: 'automatic',
    duration: 15,
    description: '১৫ সেকেন্ডের জন্য এই প্রিমিয়াম স্পন্সর বিজ্ঞাপনটি দেখুন এবং ২০ পয়সা সাথে সাথে সংগ্রহ করুন। দৈনিক সীমাহীন!',
    claimedBy: [],
    targetUrl: 'https://earnhub.pro/sponsor-ad-slot'
  },
  {
    id: 'youtube_review_1',
    title: 'ইউটিউব ভিডিও রিভিউ',
    reward: 0.80,
    type: 'automatic',
    duration: 30,
    description: '৩০ সেকেন্ড ধরে আমাদের শিক্ষামূলক আর্নিং রিভিউ ভিডিওটি দেখুন এবং ৮০ পয়সা সাথে সাথে ব্যালেন্সে যোগ করুন। দৈনিক ১ বার!',
    claimedBy: [],
    targetUrl: 'https://youtube.com/watch?v=dQw4w9WgXcQ'
  },
  {
    id: 'premium_game_install_1',
    title: 'প্রিমিয়াম স্পন্সর গেম ইনস্টল',
    reward: 12.50,
    type: 'manual',
    description: 'অ্যাপটি ডাউনলোড করুন, ইনস্টল করুন এবং ডাউনলোডের একটি স্ক্রিনশট নিয়ে এখানে জমা দিন।',
    claimedBy: [],
    targetUrl: 'https://play.google.com/store/apps/details?id=com.earnhub.pro'
  },
  {
    id: 'web_visit_1',
    title: 'স্পন্সর ওয়েবসাইট ভিজিট টাস্ক',
    reward: 1.50,
    type: 'web_visit',
    duration: 15,
    description: 'তিনটি ধাপে মোট ৪৫ সেকেন্ড ওয়েবসাইটটি ঘুরে দেখুন এবং ১.৫০ টাকা সাথে সাথে ক্রেডিট সংগ্রহ করুন!',
    claimedBy: [],
    targetUrl: 'https://earnhub.pro/visit-partner-site-1',
    soldOut: false
  }
];

// Default gateway configurations
const DEFAULT_GATEWAYS: GatewayConfig[] = [
  { id: 'bKash', name: 'bKash', min: 200, max: 20000, soldOut: false },
  { id: 'Nagad', name: 'Nagad', min: 200, max: 20000, soldOut: false },
  { id: 'Rocket', name: 'Rocket', min: 200, max: 20000, soldOut: false },
  { id: 'Binance', name: 'Binance', min: 200, max: 20000, soldOut: false }
];

// Default account sold configurations
const DEFAULT_ACCOUNT_CONFIGS: AccountConfig[] = [
  { id: 'gmail', title: 'Gmail Accounts', reward: 5.00, soldOut: false, description: 'Create and verify new Gmail accounts.' },
  { id: 'telegram', title: 'Telegram Accounts', reward: 3.50, soldOut: false, description: 'Create and verify new Telegram accounts.' },
  { id: 'instagram', title: 'Instagram Accounts', reward: 4.00, soldOut: false, description: 'Create new Instagram profiles and follow specified users.' },
  { id: 'facebook', title: 'Facebook Profiles', reward: 4.25, soldOut: false, description: 'Create and verify new Facebook profiles.' }
];

class LocalDatabase {
  private listeners: Set<() => void> = new Set();

  constructor() {
    this.init();
  }

  private init() {
    if (!localStorage.getItem(LOCAL_DB_KEYS.USERS)) {
      localStorage.setItem(LOCAL_DB_KEYS.USERS, JSON.stringify([]));
    }
    if (!localStorage.getItem(LOCAL_DB_KEYS.TASKS)) {
      localStorage.setItem(LOCAL_DB_KEYS.TASKS, JSON.stringify(DEFAULT_TASKS));
    }
    if (!localStorage.getItem(LOCAL_DB_KEYS.SUBMISSIONS)) {
      localStorage.setItem(LOCAL_DB_KEYS.SUBMISSIONS, JSON.stringify([]));
    }
    if (!localStorage.getItem(LOCAL_DB_KEYS.WITHDRAWALS)) {
      localStorage.setItem(LOCAL_DB_KEYS.WITHDRAWALS, JSON.stringify([]));
    }
    if (!localStorage.getItem(LOCAL_DB_KEYS.REFERRALS)) {
      localStorage.setItem(LOCAL_DB_KEYS.REFERRALS, JSON.stringify([]));
    }
    if (!localStorage.getItem(LOCAL_DB_KEYS.GATEWAYS)) {
      localStorage.setItem(LOCAL_DB_KEYS.GATEWAYS, JSON.stringify(DEFAULT_GATEWAYS));
    }
    const existingConfigs = localStorage.getItem(LOCAL_DB_KEYS.ACCOUNT_CONFIGS);
    if (!existingConfigs) {
      localStorage.setItem(LOCAL_DB_KEYS.ACCOUNT_CONFIGS, JSON.stringify(DEFAULT_ACCOUNT_CONFIGS));
    } else {
      try {
        const parsed = JSON.parse(existingConfigs);
        const isOld = parsed.some((c: any) => c.reward > 4.5 || (c.description && c.description.includes('একটি সম্পূর্ণ নতুন')));
        if (isOld) {
          localStorage.setItem(LOCAL_DB_KEYS.ACCOUNT_CONFIGS, JSON.stringify(DEFAULT_ACCOUNT_CONFIGS));
        }
      } catch (e) {
        localStorage.setItem(LOCAL_DB_KEYS.ACCOUNT_CONFIGS, JSON.stringify(DEFAULT_ACCOUNT_CONFIGS));
      }
    }
    if (!localStorage.getItem(LOCAL_DB_KEYS.SUBMITTED_ACCOUNTS)) {
      localStorage.setItem(LOCAL_DB_KEYS.SUBMITTED_ACCOUNTS, JSON.stringify([]));
    }
  }

  getAccountConfigs(): AccountConfig[] {
    return JSON.parse(localStorage.getItem(LOCAL_DB_KEYS.ACCOUNT_CONFIGS) || '[]');
  }

  saveAccountConfigs(configs: AccountConfig[]) {
    localStorage.setItem(LOCAL_DB_KEYS.ACCOUNT_CONFIGS, JSON.stringify(configs));
    this.notify();
  }

  getSubmittedAccounts(): SubmittedAccount[] {
    return JSON.parse(localStorage.getItem(LOCAL_DB_KEYS.SUBMITTED_ACCOUNTS) || '[]');
  }

  saveSubmittedAccounts(subs: SubmittedAccount[]) {
    localStorage.setItem(LOCAL_DB_KEYS.SUBMITTED_ACCOUNTS, JSON.stringify(subs));
    this.notify();
  }

  getGateways(): GatewayConfig[] {
    return JSON.parse(localStorage.getItem(LOCAL_DB_KEYS.GATEWAYS) || '[]');
  }

  saveGateways(gates: GatewayConfig[]) {
    localStorage.setItem(LOCAL_DB_KEYS.GATEWAYS, JSON.stringify(gates));
    this.notify();
  }

  subscribe(listener: () => void) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  notify() {
    this.listeners.forEach(l => l());
  }

  getUsers(): AppUser[] {
    return JSON.parse(localStorage.getItem(LOCAL_DB_KEYS.USERS) || '[]');
  }

  saveUsers(users: AppUser[]) {
    localStorage.setItem(LOCAL_DB_KEYS.USERS, JSON.stringify(users));
    this.notify();
  }

  getTasks(): EarnTask[] {
    return JSON.parse(localStorage.getItem(LOCAL_DB_KEYS.TASKS) || '[]');
  }

  saveTasks(tasks: EarnTask[]) {
    localStorage.setItem(LOCAL_DB_KEYS.TASKS, JSON.stringify(tasks));
    this.notify();
  }

  getSubmissions(): TaskSubmission[] {
    return JSON.parse(localStorage.getItem(LOCAL_DB_KEYS.SUBMISSIONS) || '[]');
  }

  saveSubmissions(subs: TaskSubmission[]) {
    localStorage.setItem(LOCAL_DB_KEYS.SUBMISSIONS, JSON.stringify(subs));
    this.notify();
  }

  getWithdrawals(): WithdrawalRequest[] {
    return JSON.parse(localStorage.getItem(LOCAL_DB_KEYS.WITHDRAWALS) || '[]');
  }

  saveWithdrawals(withs: WithdrawalRequest[]) {
    localStorage.setItem(LOCAL_DB_KEYS.WITHDRAWALS, JSON.stringify(withs));
    this.notify();
  }

  getReferrals(): ReferralRecord[] {
    return JSON.parse(localStorage.getItem(LOCAL_DB_KEYS.REFERRALS) || '[]');
  }

  saveReferrals(refs: ReferralRecord[]) {
    localStorage.setItem(LOCAL_DB_KEYS.REFERRALS, JSON.stringify(refs));
    this.notify();
  }
}

const localDbInstance = new LocalDatabase();

// ------------------------------------
// SYSTEM ERROR WRAPPER & ERROR INFO
// ------------------------------------
export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null, userId?: string) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: userId || firebaseAuth?.currentUser?.uid || 'offline_user',
      email: firebaseAuth?.currentUser?.email || 'offline_user@earnhub.com',
      emailVerified: firebaseAuth?.currentUser?.emailVerified || false,
      isAnonymous: firebaseAuth?.currentUser?.isAnonymous || false,
    },
    operationType,
    path
  };
  console.error('Firestore Error Details: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// ------------------------------------
// AUTHENTICATION INTERFACE (BRIDGED)
// ------------------------------------
let offlineUserData: AppUser | null = null;
let currentAuthStateListener: ((user: AppUser | null) => void) | null = null;

// Read existing current user from storage of offline simulations
const savedUid = localStorage.getItem(LOCAL_DB_KEYS.CURRENT_USER_ID);
if (savedUid) {
  const users = localDbInstance.getUsers();
  const matched = users.find(u => u.uid === savedUid);
  if (matched) {
    offlineUserData = matched;
  }
}

export const authService = {
  // Sets listener for auth changes
  onStateChanged: (callback: (user: AppUser | null) => void) => {
    if (isFirebaseReady && firebaseAuth) {
      // Real firebase auth sync with users collection
      return onAuthStateChanged(firebaseAuth, async (fbUser) => {
        if (fbUser) {
          const userDocRef = doc(firestoreDb, 'users', fbUser.uid);
          try {
            const userDocSnap = await getDoc(userDocRef);
            if (userDocSnap.exists()) {
              callback(userDocSnap.data() as AppUser);
            } else {
              // Not yet registered in collection - create user with registration bonus
              const newUser: AppUser = {
                uid: fbUser.uid,
                email: fbUser.email || 'user@earnhub.pro',
                balance: 1.00, // Sign-up bonus ৳1.00
                totalEarned: 0.00,
                referralCode: 'EHP-' + Math.floor(100000 + Math.random() * 90000).toString(),
                createdAt: new Date().toISOString(),
                isAdmin: fbUser.email === 'bristysadia10@gmail.com' // From rules & metadata
              };
              await setDoc(userDocRef, newUser);
              callback(newUser);
            }
          } catch (err) {
            console.error('Error matching Firebase Auth User profile', err);
            callback(null);
          }
        } else {
          callback(null);
        }
      });
    } else {
      // Offline local auth sync
      currentAuthStateListener = callback;
      callback(offlineUserData);
      // Listen to Db changes to update state
      return localDbInstance.subscribe(() => {
        if (offlineUserData) {
          const users = localDbInstance.getUsers();
          const fresh = users.find(u => u.uid === offlineUserData?.uid);
          if (fresh) {
            offlineUserData = fresh;
            if (currentAuthStateListener) currentAuthStateListener(fresh);
          }
        }
      });
    }
  },

  // Signup with starting bonus
  signUp: async (email: string, referralCodeEntered?: string, fullName?: string, phoneNumber?: string, password?: string): Promise<AppUser> => {
    const signupBonus = 1.00; // Registration Reward ৳1.00
    const finalEmail = email.trim();
    const uid = 'user_' + Math.floor(100000 + Math.random() * 900000).toString();
    const cleanReferral = referralCodeEntered ? referralCodeEntered.trim().toUpperCase() : undefined;

    // 1. Real Referential code verification before starting execution
    if (cleanReferral) {
      if (isFirebaseReady && firestoreDb) {
        try {
          const usersSnap = await getDocs(query(collection(firestoreDb, 'users'), where('referralCode', '==', cleanReferral), limit(1)));
          if (usersSnap.empty) {
            throw new Error('প্রবেশ করানো রেফার কোডটি সঠিক নয়! দয়া করে সঠিক কোড দিন অথবা এটি ফাঁকা রাখুন।');
          }
        } catch (err: any) {
          if (err.message && err.message.includes('রেফার কোডটি সঠিক নয়')) {
            throw err;
          }
          console.warn("Firestore refer validation fallback:", err);
        }
      } else {
        const users = localDbInstance.getUsers();
        const matched = users.find(u => u.referralCode === cleanReferral);
        if (!matched) {
          throw new Error('প্রবেশ করানো রেফার কোডটি সঠিক নয়! দয়া করে সঠিক কোড দিন অথবা এটি ফাঁকা রাখুন।');
        }
      }
    }
    
    if (isFirebaseReady && firebaseAuth) {
      try {
        let referrerUid: string | undefined = undefined;
        if (cleanReferral) {
          const usersSnap = await getDocs(query(collection(firestoreDb, 'users'), where('referralCode', '==', cleanReferral), limit(1)));
          if (!usersSnap.empty) {
            referrerUid = usersSnap.docs[0].id;
          }
        }

        // Fallback email password or Google credentials on Firebase Auth
        const cred = await createUserWithEmailAndPassword(firebaseAuth, finalEmail, password || "EarnHub@123");
        const referralCode = 'EHP-' + Math.floor(100000 + Math.random() * 90000).toString();
        const newUser: AppUser = {
          uid: cred.user.uid,
          email: finalEmail,
          fullName: fullName || '',
          phoneNumber: phoneNumber || '',
          balance: signupBonus,
          totalEarned: 0.00,
          referralCode,
          referredBy: referrerUid,
          createdAt: new Date().toISOString(),
          isAdmin: finalEmail === 'bristysadia10@gmail.com'
        };

        const path = `users/${cred.user.uid}`;
        try {
          await setDoc(doc(firestoreDb, 'users', cred.user.uid), newUser);
          
          if (referrerUid) {
            // Log Referral Record but with zero reward since we are on 10% cashout commission model
            await addDoc(collection(firestoreDb, 'referrals'), {
              referrerUid,
              refereeUid: cred.user.uid,
              refereeEmail: finalEmail,
              reward: 0.00,
              createdAt: new Date().toISOString()
            });
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.CREATE, path, cred.user.uid);
        }
        
        return newUser;
      } catch (err: any) {
        if (err.message && err.message.includes('রেফার কোডটি সঠিক নয়')) {
          throw err;
        }
        console.error("Firebase signup error, switching to simulation signup", err);
      }
    }

    // Offline registration simulation
    const users = localDbInstance.getUsers();
    const existing = users.find(u => u.email.toLowerCase() === finalEmail.toLowerCase());
    if (existing) {
      offlineUserData = existing;
      localStorage.setItem(LOCAL_DB_KEYS.CURRENT_USER_ID, existing.uid);
      if (currentAuthStateListener) currentAuthStateListener(existing);
      return existing;
    }

    let referrerUidSim: string | undefined = undefined;
    if (cleanReferral) {
      const referrerIndex = users.findIndex(u => u.referralCode === cleanReferral);
      if (referrerIndex !== -1) {
        referrerUidSim = users[referrerIndex].uid;
      }
    }

    const referralCode = 'EHP-' + Math.floor(100000 + Math.random() * 90000).toString();
    const newUser: AppUser & { password?: string } = {
      uid,
      email: finalEmail,
      fullName: fullName || '',
      phoneNumber: phoneNumber || '',
      balance: signupBonus,
      totalEarned: 0.00,
      referralCode,
      referredBy: referrerUidSim,
      createdAt: new Date().toISOString(),
      isAdmin: finalEmail === 'bristysadia10@gmail.com', // True for supervisor email
      password: password
    };

    users.push(newUser);
    localDbInstance.saveUsers(users);

    if (referrerUidSim) {
      // Log Referral record with 0 reward
      const refs = localDbInstance.getReferrals();
      refs.push({
        id: 'ref_' + Math.floor(Math.random() * 900000).toString(),
        referrerUid: referrerUidSim,
        refereeUid: uid,
        refereeEmail: finalEmail,
        reward: 0.00,
        createdAt: new Date().toISOString()
      });
      localDbInstance.saveReferrals(refs);
    }

    offlineUserData = newUser;
    localStorage.setItem(LOCAL_DB_KEYS.CURRENT_USER_ID, uid);
    if (currentAuthStateListener) currentAuthStateListener(newUser);
    return newUser;
  },

  // Offline or real signin
  signIn: async (email: string, password?: string): Promise<AppUser> => {
    const finalEmail = email.trim();
    const isSuperAdmin = finalEmail.toLowerCase() === 'bristysadia10@gmail.com';

    // Super Admin strictly matches credentials
    if (isSuperAdmin) {
      if (password !== 'Rabby@#$379') {
        throw new Error('ভুল ইমেইল অথবা পাসওয়ার্ড! ❌');
      }
    }

    if (isFirebaseReady && firebaseAuth) {
      try {
        const cred = await signInWithEmailAndPassword(firebaseAuth, finalEmail, password || "EarnHub@123");
        const userDoc = await getDoc(doc(firestoreDb, 'users', cred.user.uid));
        if (userDoc.exists()) {
          const userObj = userDoc.data() as AppUser;
          if (userObj.isBlocked) {
            throw new Error('আপনার একাউন্টটি সাময়িকভাবে ব্লক করা হয়েছে! ❌');
          }
          return userObj;
        }
      } catch (err) {
        throw new Error('ভুল ইমেইল অথবা পাসওয়ার্ড! ❌');
      }
    }

    // Try finding in offline users
    const users = localDbInstance.getUsers();
    
    // Auto-seed production admin account if needed
    if (isSuperAdmin) {
      const existingAdmin = users.find(u => u.email.toLowerCase() === 'bristysadia10@gmail.com');
      if (!existingAdmin) {
        const seededAdmin: AppUser & { password?: string } = {
          uid: 'admin_super_1',
          email: 'bristysadia10@gmail.com',
          fullName: 'Super Admin',
          phoneNumber: '01302517769',
          balance: 99999,
          totalEarned: 99999,
          referralCode: 'EHP-ADMIN',
          createdAt: new Date().toISOString(),
          isAdmin: true,
          password: 'Rabby@#$379'
        };
        users.push(seededAdmin);
        localDbInstance.saveUsers(users);
      }
    }

    let user = users.find(u => u.email.toLowerCase() === finalEmail.toLowerCase());
    
    if (!user) {
      throw new Error('ভুল ইমেইল অথবা পাসওয়ার্ড! ❌');
    }

    // Verify Password on Simulation
    if (password) {
      const userWithPass = user as any;
      if (userWithPass.password && userWithPass.password !== password) {
        throw new Error('ভুল ইমেইল অথবা পাসওয়ার্ড! ❌');
      }
    } else if (user.email !== 'earner@test.com') {
      throw new Error('ভুল ইমেইল অথবা পাসওয়ার্ড! ❌');
    }

    if (user.isBlocked) {
      throw new Error('আপনার একাউন্টটি সাময়িকভাবে ব্লক করা হয়েছে! ❌');
    }

    offlineUserData = user;
    localStorage.setItem(LOCAL_DB_KEYS.CURRENT_USER_ID, user.uid);
    if (currentAuthStateListener) currentAuthStateListener(user);

    return user;
  },

  signOut: async () => {
    if (isFirebaseReady && firebaseAuth) {
      await signOut(firebaseAuth);
    }
    offlineUserData = null;
    localStorage.removeItem(LOCAL_DB_KEYS.CURRENT_USER_ID);
    if (currentAuthStateListener) currentAuthStateListener(null);
  },

  getCurrentUser: (): AppUser | null => {
    return offlineUserData;
  }
};

// ------------------------------------
// DATABASE OPERATION SERVICES
// ------------------------------------
export const databaseService = {
  // Live fetch of Earn Tasks
  getTasks: async (): Promise<EarnTask[]> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const snap = await getDocs(collection(firestoreDb, 'tasks'));
        if (!snap.empty) {
          return snap.docs.map(d => ({ id: d.id, ...d.data() } as EarnTask));
        }
      } catch (error) {
        console.warn('Unable to get tasks from Firestore, serving offline fallback', error);
      }
    }
    return localDbInstance.getTasks();
  },

  // Real-time listener for tasks
  subscribeTasks: (callback: (tasks: EarnTask[]) => void) => {
    if (isFirebaseReady && firestoreDb) {
      try {
        return onSnapshot(collection(firestoreDb, 'tasks'), (snap) => {
          const list = snap.docs.map(d => ({ id: d.id, ...d.data() } as any));
          callback(list);
        }, (error) => {
          console.error("Firestore onSnapshot error:", error);
        });
      } catch (error) {
        console.warn("Unable to subscribe to Firestore tasks, falling back to local simulation", error);
      }
    }
    
    // Fallback block - local storage subscription
    callback(localDbInstance.getTasks());
    return localDbInstance.subscribe(() => {
      callback(localDbInstance.getTasks());
    });
  },

  // Create custom earn task
  createTask: async (taskName: string, taskUrl: string, taskReward: number, downloadLink?: string, duration?: number, taskType: 'automatic' | 'manual' | 'web_visit' = 'manual'): Promise<void> => {
    const docData = {
      title: taskName,
      link: taskUrl,
      reward: Number(taskReward),
      status: "Active",
      type: taskType,
      description: taskType === 'web_visit' 
        ? "তিনটি ধাপে মোট ৪৫ সেকেন্ড ওয়েবসাইটটি ঘুরে দেখুন এবং রিওয়ার্ড সংগ্রহ করুন।" 
        : "অ্যাপটি ডাউনলোড করুন, ইনস্টল করুন এবং ডাউনলোডের একটি স্ক্রিনশট নিয়ে এখানে জমা দিন।",
      claimedBy: [],
      targetUrl: taskUrl, // For backward compatibility
      downloadLink: downloadLink || "",
      duration: duration || 15,
      soldOut: false,
      createdAt: new Date().toISOString()
    };

    if (isFirebaseReady && firestoreDb) {
      try {
        await addDoc(collection(firestoreDb, 'tasks'), docData);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, 'tasks');
      }
    } else {
      const tasks = localDbInstance.getTasks();
      const taskWithId = {
        ...docData,
        id: 'task_' + Math.floor(100000 + Math.random() * 900000).toString()
      };
      tasks.push(taskWithId as any);
      localDbInstance.saveTasks(tasks);
    }
  },

  // Get active referrals for real-time visualization of invites progress
  getReferralsByUser: async (userId: string): Promise<ReferralRecord[]> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const q = query(collection(firestoreDb, 'referrals'), where('referrerUid', '==', userId));
        const snap = await getDocs(q);
        return snap.docs.map(doc => ({ id: doc.id, ...doc.data() }) as ReferralRecord);
      } catch (error) {
        console.error('Error fetching referrals:', error);
      }
    }
    return localDbInstance.getReferrals().filter(r => r.referrerUid === userId);
  },

  // Perform daily check-in (Daily checking rewards ৳0.50 to ৳5.00)
  claimDailyCheckIn: async (userId: string): Promise<number> => {
    const randomReward = Number((0.50 + Math.random() * (5.00 - 0.50)).toFixed(2));
    
    if (isFirebaseReady && firestoreDb) {
      const userRef = doc(firestoreDb, 'users', userId);
      try {
        const userDoc = await getDoc(userRef);
        if (userDoc.exists()) {
          const u = userDoc.data() as AppUser;
          await updateDoc(userRef, {
            balance: Number((u.balance + randomReward).toFixed(2)),
            totalEarned: Number((u.totalEarned + randomReward).toFixed(2))
          });
          return randomReward;
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`, userId);
      }
    }

    // Offline check-in
    const users = localDbInstance.getUsers();
    const index = users.findIndex(u => u.uid === userId);
    if (index !== -1) {
      const freshBalance = Number((users[index].balance + randomReward).toFixed(2));
      const freshTotal = Number((users[index].totalEarned + randomReward).toFixed(2));
      users[index].balance = freshBalance;
      users[index].totalEarned = freshTotal;
      localDbInstance.saveUsers(users);
    }
    return randomReward;
  },

  // Automatic verification claim (Credits ৳0.15 for sponsored ad, ৳0.80 for YouTube Review instantly)
  claimAutomaticTask: async (userId: string, taskId: string, reward: number): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      const userRef = doc(firestoreDb, 'users', userId);
      try {
        const userDoc = await getDoc(userRef);
        if (userDoc.exists()) {
          const u = userDoc.data() as AppUser;
          await updateDoc(userRef, {
            balance: Number((u.balance + reward).toFixed(2)),
            totalEarned: Number((u.totalEarned + reward).toFixed(2))
          });
          // Track that the automatic task has been completed directly (We can also store completed tasks list)
          if (taskId !== 'sponsor_ad_1') {
            const taskRef = doc(firestoreDb, 'tasks', taskId);
            const taskDoc = await getDoc(taskRef);
            if (taskDoc.exists()) {
              const taskData = taskDoc.data() as EarnTask;
              const claimedList = taskData.claimedBy || [];
              if (!claimedList.includes(userId)) {
                await updateDoc(taskRef, {
                  claimedBy: [...claimedList, userId]
                });
              }
            }
          }
          return;
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${userId}`, userId);
      }
    }

    // Offline simulation claim
    const users = localDbInstance.getUsers();
    const uIndex = users.findIndex(u => u.uid === userId);
    if (uIndex !== -1) {
      users[uIndex].balance = Number((users[uIndex].balance + reward).toFixed(2));
      users[uIndex].totalEarned = Number((users[uIndex].totalEarned + reward).toFixed(2));
      localDbInstance.saveUsers(users);
    }

    if (taskId !== 'sponsor_ad_1') {
      const tasks = localDbInstance.getTasks();
      const tIndex = tasks.findIndex(t => t.id === taskId);
      if (tIndex !== -1) {
        if (!tasks[tIndex].claimedBy.includes(userId)) {
          tasks[tIndex].claimedBy.push(userId);
          localDbInstance.saveTasks(tasks);
        }
      }
    }
  },

  // Submit manual screenshot task ("প্রিমিয়াম স্পন্সর গেম ইনস্টল") - status starts as "Pending"
  submitManualTask: async (userId: string, userEmail: string, taskName: string, taskId: string, reward: number, base64Screenshot: string): Promise<void> => {
    const submission: TaskSubmission = {
      id: 'sub_' + Math.floor(100000 + Math.random() * 900000).toString(),
      userId,
      userEmail,
      taskName,
      taskId,
      screenshotUrl: base64Screenshot, // stored locally as base64 string
      status: 'Pending',
      reward,
      createdAt: new Date().toISOString()
    };

    if (isFirebaseReady && firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, 'task_submissions', submission.id), submission);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `task_submissions/${submission.id}`, userId);
      }
    }

    // Offline state representation
    const subs = localDbInstance.getSubmissions();
    subs.push(submission);
    localDbInstance.saveSubmissions(subs);
  },

  // Subscribe to manual submissions (Useful for real-time admin view or user state view)
  getSubmissions: async (): Promise<TaskSubmission[]> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const snap = await getDocs(collection(firestoreDb, 'task_submissions'));
        return snap.docs.map(doc => doc.data() as TaskSubmission);
      } catch (error) {
        console.error("Error reading task submissions", error);
      }
    }
    return localDbInstance.getSubmissions();
  },

  // Approve manual task submission (Credits balance instantly, status -> Approved)
  approveSubmission: async (id: string): Promise<void> => {
    let targetUid = '';
    let targetEmail = '';
    let rewardValue = 0;
    let taskIdRef = '';

    if (isFirebaseReady && firestoreDb) {
      try {
        const subRef = doc(firestoreDb, 'task_submissions', id);
        const subSnap = await getDoc(subRef);
        if (subSnap.exists()) {
          const sub = subSnap.data() as TaskSubmission;
          targetUid = sub.userId;
          rewardValue = sub.reward;
          taskIdRef = sub.taskId;

          // Update submission status to 'Approved'
          await updateDoc(subRef, { status: 'Approved' });

          // Credit balance of the owner user
          const userRef = doc(firestoreDb, 'users', targetUid);
          const userDoc = await getDoc(userRef);
          if (userDoc.exists()) {
            const u = userDoc.data() as AppUser;
            await updateDoc(userRef, {
              balance: Number((u.balance + rewardValue).toFixed(2)),
              totalEarned: Number((u.totalEarned + rewardValue).toFixed(2))
            });
          }

          // Mark task as claimed for that user
          const taskRef = doc(firestoreDb, 'tasks', taskIdRef);
          const taskDoc = await getDoc(taskRef);
          if (taskDoc.exists()) {
            const t = taskDoc.data() as EarnTask;
            const list = t.claimedBy || [];
            if (!list.includes(targetUid)) {
              await updateDoc(taskRef, { claimedBy: [...list, targetUid] });
            }
          }
        }
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `task_submissions/${id}`);
      }
    }

    // Local Storage Simulation Action
    const subs = localDbInstance.getSubmissions();
    const subIndex = subs.findIndex(s => s.id === id);
    if (subIndex !== -1 && subs[subIndex].status === 'Pending') {
      const sub = subs[subIndex];
      subs[subIndex].status = 'Approved';
      localDbInstance.saveSubmissions(subs);

      // Credit User Balance
      const users = localDbInstance.getUsers();
      const userIndex = users.findIndex(u => u.uid === sub.userId);
      if (userIndex !== -1) {
        users[userIndex].balance = Number((users[userIndex].balance + sub.reward).toFixed(2));
        users[userIndex].totalEarned = Number((users[userIndex].totalEarned + sub.reward).toFixed(2));
        localDbInstance.saveUsers(users);
      }

      // Mark as claimed
      const tasks = localDbInstance.getTasks();
      const taskIndex = tasks.findIndex(t => t.id === sub.taskId);
      if (taskIndex !== -1) {
        if (!tasks[taskIndex].claimedBy.includes(sub.userId)) {
          tasks[taskIndex].claimedBy.push(sub.userId);
          localDbInstance.saveTasks(tasks);
        }
      }
    }
  },

  // Reject manual task submission
  rejectSubmission: async (id: string): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        await updateDoc(doc(firestoreDb, 'task_submissions', id), { status: 'Rejected' });
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `task_submissions/${id}`);
      }
    }

    // Local storage simulation rejection
    const subs = localDbInstance.getSubmissions();
    const index = subs.findIndex(s => s.id === id);
    if (index !== -1 && subs[index].status === 'Pending') {
      subs[index].status = 'Rejected';
      localDbInstance.saveSubmissions(subs);
    }
  },

  // Request payout withdrawal (min 200)
  requestWithdrawal: async (userId: string, userEmail: string, amount: number, paymentMethod: 'bKash' | 'Nagad' | 'Rocket' | 'Binance', accountNumber: string): Promise<void> => {
    const minPayout = 200; // Minimum limit ৳200
    if (amount < minPayout) {
      throw new Error(`সর্বনিম্ন উত্তোলন ৳${minPayout} টাকা হতে হবে।`);
    }

    // Deduct current balance first
    if (isFirebaseReady && firestoreDb) {
      const userRef = doc(firestoreDb, 'users', userId);
      try {
        const userDoc = await getDoc(userRef);
        if (userDoc.exists()) {
          const u = userDoc.data() as AppUser;
          if (u.balance < amount) {
            throw new Error(`আপনার একাউন্টে পর্যাপ্ত ব্যালেন্স নেই। বর্তমান ব্যালেন্স: ৳${u.balance}`);
          }

          // Deduct from balance
          await updateDoc(userRef, {
            balance: Number((u.balance - amount).toFixed(2))
          });

          // Register Payout request
          const withdrawalReq: WithdrawalRequest = {
            id: 'withdraw_' + Math.floor(100000 + Math.random() * 900000).toString(),
            userId,
            userEmail,
            amount,
            paymentMethod,
            accountNumber,
            status: 'Pending',
            createdAt: new Date().toISOString()
          };

          await setDoc(doc(firestoreDb, 'withdrawals', withdrawalReq.id), withdrawalReq);
          return;
        }
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `withdrawals`, userId);
      }
    }

    // Offline balance check and withdrawal simulation
    const users = localDbInstance.getUsers();
    const userIndex = users.findIndex(u => u.uid === userId);
    if (userIndex !== -1) {
      const u = users[userIndex];
      if (u.balance < amount) {
        throw new Error(`আপনার একাউন্টে পর্যাপ্ত ব্যালেন্স নেই। বর্তমান ব্যালেন্স: ৳${u.balance}`);
      }

      // Deduct balance
      users[userIndex].balance = Number((u.balance - amount).toFixed(2));
      localDbInstance.saveUsers(users);

      // Create withdrawal request
      const req: WithdrawalRequest = {
        id: 'withdraw_' + Math.floor(100000 + Math.random() * 900000).toString(),
        userId,
        userEmail,
        amount,
        paymentMethod,
        accountNumber,
        status: 'Pending',
        createdAt: new Date().toISOString()
      };

      const withdrawals = localDbInstance.getWithdrawals();
      withdrawals.push(req);
      localDbInstance.saveWithdrawals(withdrawals);
    }
  },

  // Get active withdrawal requests
  getWithdrawals: async (): Promise<WithdrawalRequest[]> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const snap = await getDocs(collection(firestoreDb, 'withdrawals'));
        return snap.docs.map(doc => doc.data() as WithdrawalRequest);
      } catch (error) {
        console.error("Error reading withdrawals", error);
      }
    }
    return localDbInstance.getWithdrawals();
  },

  // Admin approval of withdrawal request (Marks request as approved)
  approveWithdrawal: async (id: string): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const withRef = doc(firestoreDb, 'withdrawals', id);
        const snap = await getDoc(withRef);
        if (snap.exists()) {
          const wr = snap.data() as WithdrawalRequest;
          if (wr.status === 'Pending') {
            // Get user to check referredBy
            const uRef = doc(firestoreDb, 'users', wr.userId);
            const uSnap = await getDoc(uRef);
            if (uSnap.exists()) {
              const u = uSnap.data() as AppUser;
              if (u.referredBy) {
                // Fetch current config for commission %
                const configDoc = await getDoc(doc(firestoreDb, 'system_config', 'main_config'));
                const commPercent = configDoc.exists() ? (configDoc.data()?.withdrawalCommissionPercent ?? 10) : 10;
                const commission = Number((wr.amount * (commPercent / 100)).toFixed(2));
                
                if (commission > 0) {
                  // Credit referrer's account
                  const refUserRef = doc(firestoreDb, 'users', u.referredBy);
                  const refUserSnap = await getDoc(refUserRef);
                  if (refUserSnap.exists()) {
                    const referrerData = refUserSnap.data() as AppUser;
                    await updateDoc(refUserRef, {
                      balance: Number((referrerData.balance + commission).toFixed(2)),
                      totalEarned: Number((referrerData.totalEarned + commission).toFixed(2))
                    });

                    // Update corresponding referral record to reflect this added commission reward
                    const referralsSnap = await getDocs(query(
                      collection(firestoreDb, 'referrals'),
                      where('referrerUid', '==', u.referredBy),
                      where('refereeUid', '==', wr.userId),
                      limit(1)
                    ));
                    if (!referralsSnap.empty) {
                      const refRecDoc = referralsSnap.docs[0];
                      const currentReward = refRecDoc.data().reward || 0.00;
                      await updateDoc(doc(firestoreDb, 'referrals', refRecDoc.id), {
                        reward: Number((currentReward + commission).toFixed(2))
                      });
                    }
                  }
                }
              }
            }
            // Mark the withdrawal request as Approved
            await updateDoc(withRef, { status: 'Approved' });
          }
        }
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `withdrawals/${id}`);
      }
    }

    // Local Storage Action
    const withs = localDbInstance.getWithdrawals();
    const index = withs.findIndex(w => w.id === id);
    if (index !== -1 && withs[index].status === 'Pending') {
      const wr = withs[index];
      const users = localDbInstance.getUsers();
      const userIndex = users.findIndex(u => u.uid === wr.userId);
      if (userIndex !== -1) {
        const u = users[userIndex];
        if (u.referredBy) {
          const localConfigStr = localStorage.getItem('earnhub_system_config');
          let commPercent = 10;
          if (localConfigStr) {
            try { commPercent = JSON.parse(localConfigStr).withdrawalCommissionPercent ?? 10; } catch(e) {}
          }
          const commission = Number((wr.amount * (commPercent / 100)).toFixed(2));
          if (commission > 0) {
            const refIndex = users.findIndex(ru => ru.uid === u.referredBy);
            if (refIndex !== -1) {
              users[refIndex].balance = Number((users[refIndex].balance + commission).toFixed(2));
              users[refIndex].totalEarned = Number((users[refIndex].totalEarned + commission).toFixed(2));
              
              // Local refer record reward update
              const refs = localDbInstance.getReferrals();
              const refLogIndex = refs.findIndex(r => r.referrerUid === u.referredBy && r.refereeUid === wr.userId);
              if (refLogIndex !== -1) {
                refs[refLogIndex].reward = Number(((refs[refLogIndex].reward || 0) + commission).toFixed(2));
                localDbInstance.saveReferrals(refs);
              }
            }
          }
        }
      }
      withs[index].status = 'Approved';
      localDbInstance.saveWithdrawals(withs);
      localDbInstance.saveUsers(users);
    }
  },

  // Admin rejection of withdrawal request (Restores user balance!)
  rejectWithdrawal: async (id: string): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const withRef = doc(firestoreDb, 'withdrawals', id);
        const snap = await getDoc(withRef);
        if (snap.exists()) {
          const wr = snap.data() as WithdrawalRequest;
          // Restore user balance
          const uRef = doc(firestoreDb, 'users', wr.userId);
          const uSnap = await getDoc(uRef);
          if (uSnap.exists()) {
            const u = uSnap.data() as AppUser;
            await updateDoc(uRef, {
              balance: Number((u.balance + wr.amount).toFixed(2))
            });
          }
          // Mark as rejected
          await updateDoc(withRef, { status: 'Rejected' });
        }
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `withdrawals/${id}`);
      }
    }

    // Offline simulation rejection and refund
    const withs = localDbInstance.getWithdrawals();
    const index = withs.findIndex(w => w.id === id);
    if (index !== -1 && withs[index].status === 'Pending') {
      const w = withs[index];
      w.status = 'Rejected';
      localDbInstance.saveWithdrawals(withs);

      // Refund User
      const users = localDbInstance.getUsers();
      const userIndex = users.findIndex(u => u.uid === w.userId);
      if (userIndex !== -1) {
        users[userIndex].balance = Number((users[userIndex].balance + w.amount).toFixed(2));
        localDbInstance.saveUsers(users);
      }
    }
  },

  // Get all users for admin search & management
  getAllUsers: async (): Promise<AppUser[]> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const snap = await getDocs(collection(firestoreDb, 'users'));
        return snap.docs.map(doc => ({ uid: doc.id, ...doc.data() } as AppUser));
      } catch (error) {
        console.error("Error reading all users from Firestore:", error);
      }
    }
    return localDbInstance.getUsers();
  },

  // Update user specific wallet fields (e.g. balance, totalEarned, isBlocked)
  updateUserFields: async (uid: string, fields: Partial<AppUser>): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        await updateDoc(doc(firestoreDb, 'users', uid), fields);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `users/${uid}`);
      }
    }

    // Local simulation update
    const users = localDbInstance.getUsers();
    const index = users.findIndex(u => u.uid === uid);
    if (index !== -1) {
      users[index] = { ...users[index], ...fields };
      localDbInstance.saveUsers(users);
    }
  },

  // Get gateway configurations (e.g. bKash, Nagad, Rocket, Binance)
  getGateways: async (): Promise<GatewayConfig[]> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const snap = await getDocs(collection(firestoreDb, 'gateways'));
        if (snap.empty) {
          // Initialize firestore gateways with default gateways
          for (const gate of DEFAULT_GATEWAYS) {
            await setDoc(doc(firestoreDb, 'gateways', gate.id), gate);
          }
          return DEFAULT_GATEWAYS;
        }
        return snap.docs.map(doc => doc.data() as GatewayConfig);
      } catch (error) {
        console.error("Error reading gateways from Firestore:", error);
      }
    }
    return localDbInstance.getGateways();
  },

  // Update gateway configuration limits or status (soldOut, min, max)
  updateGatewayConfig: async (id: string, fields: Partial<GatewayConfig>): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        await updateDoc(doc(firestoreDb, 'gateways', id), fields);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `gateways/${id}`);
      }
    }

    // Local simulation update
    const gates = localDbInstance.getGateways();
    const index = gates.findIndex(g => g.id === id);
    if (index !== -1) {
      gates[index] = { ...gates[index], ...fields };
      localDbInstance.saveGateways(gates);
    }
  },

  // Update task specific fields (e.g. reward, targetUrl)
  updateTaskFields: async (id: string, fields: Partial<EarnTask>): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        await updateDoc(doc(firestoreDb, 'tasks', id), fields);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `tasks/${id}`);
      }
    }

    // Local simulation update
    const tasks = localDbInstance.getTasks();
    const index = tasks.findIndex(t => t.id === id);
    if (index !== -1) {
      tasks[index] = { ...tasks[index], ...fields };
      localDbInstance.saveTasks(tasks);
    }
  },

  // Get account configurations
  getAccountConfigs: async (): Promise<AccountConfig[]> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const snap = await getDocs(collection(firestoreDb, 'account_configs'));
        if (snap.empty) {
          for (const conf of DEFAULT_ACCOUNT_CONFIGS) {
            await setDoc(doc(firestoreDb, 'account_configs', conf.id), conf);
          }
          return DEFAULT_ACCOUNT_CONFIGS;
        }
        return snap.docs.map(doc => doc.data() as AccountConfig);
      } catch (error) {
        console.error("Error reading account configs from Firestore:", error);
      }
    }
    return localDbInstance.getAccountConfigs();
  },

  // Update account configuration
  updateAccountConfig: async (id: string, fields: Partial<AccountConfig>): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        await updateDoc(doc(firestoreDb, 'account_configs', id), fields);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `account_configs/${id}`);
      }
    }
    const configs = localDbInstance.getAccountConfigs();
    const index = configs.findIndex(c => c.id === id);
    if (index !== -1) {
      configs[index] = { ...configs[index], ...fields };
      localDbInstance.saveAccountConfigs(configs);
    }
  },

  // Submit made accounts credentials
  submitAccount: async (sub: Omit<SubmittedAccount, 'id' | 'status' | 'submittedAt'>): Promise<void> => {
    const id = 'acc_sub_' + Math.floor(100000 + Math.random() * 900000).toString();
    const submitted: SubmittedAccount = {
      ...sub,
      id,
      status: 'Pending',
      submittedAt: new Date().toISOString()
    };

    if (isFirebaseReady && firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, 'submitted_accounts', id), submitted);
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.CREATE, `submitted_accounts/${id}`, sub.userId);
      }
    }
    const subs = localDbInstance.getSubmittedAccounts();
    subs.push(submitted);
    localDbInstance.saveSubmittedAccounts(subs);
  },

  // Get submitted accounts list
  getSubmittedAccounts: async (): Promise<SubmittedAccount[]> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const snap = await getDocs(collection(firestoreDb, 'submitted_accounts'));
        return snap.docs.map(doc => doc.data() as SubmittedAccount);
      } catch (error) {
        console.error("Error reading submitted accounts from Firestore:", error);
      }
    }
    return localDbInstance.getSubmittedAccounts();
  },

  // Approve account listing and award balance
  approveAccountSubmission: async (id: string): Promise<void> => {
    let targetUid = '';
    let rewardValue = 0;

    if (isFirebaseReady && firestoreDb) {
      try {
        const subRef = doc(firestoreDb, 'submitted_accounts', id);
        const subSnap = await getDoc(subRef);
        if (subSnap.exists()) {
          const sub = subSnap.data() as SubmittedAccount;
          targetUid = sub.userId;
          rewardValue = sub.reward;

          await updateDoc(subRef, { status: 'Approved' });

          const userRef = doc(firestoreDb, 'users', targetUid);
          const userDoc = await getDoc(userRef);
          if (userDoc.exists()) {
            const u = userDoc.data() as AppUser;
            await updateDoc(userRef, {
              balance: Number((u.balance + rewardValue).toFixed(2)),
              totalEarned: Number((u.totalEarned + rewardValue).toFixed(2))
            });
          }
        }
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `submitted_accounts/${id}`);
      }
    }

    const subs = localDbInstance.getSubmittedAccounts();
    const subIndex = subs.findIndex(s => s.id === id);
    if (subIndex !== -1 && subs[subIndex].status === 'Pending') {
      const sub = subs[subIndex];
      subs[subIndex].status = 'Approved';
      localDbInstance.saveSubmittedAccounts(subs);

      const users = localDbInstance.getUsers();
      const userIndex = users.findIndex(u => u.uid === sub.userId);
      if (userIndex !== -1) {
        users[userIndex].balance = Number((users[userIndex].balance + sub.reward).toFixed(2));
        users[userIndex].totalEarned = Number((users[userIndex].totalEarned + sub.reward).toFixed(2));
        localDbInstance.saveUsers(users);
      }
    }
  },

  // Reject submitted account credentials
  rejectAccountSubmission: async (id: string): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        await updateDoc(doc(firestoreDb, 'submitted_accounts', id), { status: 'Rejected' });
        return;
      } catch (error) {
        handleFirestoreError(error, OperationType.UPDATE, `submitted_accounts/${id}`);
      }
    }

    const subs = localDbInstance.getSubmittedAccounts();
    const index = subs.findIndex(s => s.id === id);
    if (index !== -1 && subs[index].status === 'Pending') {
      subs[index].status = 'Rejected';
      localDbInstance.saveSubmittedAccounts(subs);
    }
  },

  getSystemConfig: async (): Promise<SystemConfig> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        const configDoc = await getDoc(doc(firestoreDb, 'system_config', 'main_config'));
        if (configDoc.exists()) {
          return configDoc.data() as SystemConfig;
        } else {
          const defaultConfig: SystemConfig = { withdrawalCommissionPercent: 10 };
          await setDoc(doc(firestoreDb, 'system_config', 'main_config'), defaultConfig);
          return defaultConfig;
        }
      } catch (error) {
        console.error("Error reading system config from Firestore:", error);
      }
    }
    // Simulated Local Storage
    const localConfig = localStorage.getItem('earnhub_system_config');
    if (localConfig) {
      try {
        return JSON.parse(localConfig) as SystemConfig;
      } catch (e) {}
    }
    const defaultConfig: SystemConfig = { withdrawalCommissionPercent: 10 };
    localStorage.setItem('earnhub_system_config', JSON.stringify(defaultConfig));
    return defaultConfig;
  },

  updateSystemConfig: async (fields: Partial<SystemConfig>): Promise<void> => {
    if (isFirebaseReady && firestoreDb) {
      try {
        await setDoc(doc(firestoreDb, 'system_config', 'main_config'), fields, { merge: true });
        return;
      } catch (error) {
        console.error("Error updating system config in Firestore:", error);
      }
    }
    // Simulated Local Storage
    const localConfig = localStorage.getItem('earnhub_system_config');
    let current: SystemConfig = { withdrawalCommissionPercent: 10 };
    if (localConfig) {
      try {
        current = JSON.parse(localConfig);
      } catch (e) {}
    }
    const updated = { ...current, ...fields };
    localStorage.setItem('earnhub_system_config', JSON.stringify(updated));
  },

  // Wipe simulation state (for developer resets)
  resetLocalDb: () => {
    localStorage.removeItem(LOCAL_DB_KEYS.USERS);
    localStorage.removeItem(LOCAL_DB_KEYS.TASKS);
    localStorage.removeItem(LOCAL_DB_KEYS.SUBMISSIONS);
    localStorage.removeItem(LOCAL_DB_KEYS.WITHDRAWALS);
    localStorage.removeItem(LOCAL_DB_KEYS.REFERRALS);
    localStorage.removeItem(LOCAL_DB_KEYS.CURRENT_USER_ID);
    localStorage.removeItem(LOCAL_DB_KEYS.GATEWAYS);
    localStorage.removeItem(LOCAL_DB_KEYS.ACCOUNT_CONFIGS);
    localStorage.removeItem(LOCAL_DB_KEYS.SUBMITTED_ACCOUNTS);
    window.location.reload();
  }
};
